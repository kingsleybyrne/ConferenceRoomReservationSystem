package za.co.vzap.logfile;

import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import za.co.vzap.dto.UserDTO;

//Open Source Code
/**
*
* @author All Open source developers
* @version 1.0.0.0
* @since 2014/12/22
*/
public class LogFile {
	
	public LogFile(UserDTO user,InetAddress ipAddress){
		 Logger logger = Logger.getLogger("Logins Log");  
		    FileHandler fh;  

		    try {  

		        // This block configure the logger with handler and formatter  
		        fh = new FileHandler("logfile/LoginsLog.log");  
		        logger.addHandler(fh);
		        SimpleFormatter formatter = new SimpleFormatter();  
		        fh.setFormatter(formatter);  

		        // the following statement is used to log any messages  
		        logger.info("Username: "+user.getClientUsername()+"\tIP: "+ipAddress.getAddress()+"\tHostName: "+ipAddress.getCanonicalHostName());  

		    } catch (SecurityException e) {  
		        e.printStackTrace();  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }  
	}

}

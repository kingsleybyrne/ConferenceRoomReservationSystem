package za.co.vzap.main;
import java.net.*;
import java.sql.SQLException;

import za.co.vzap.dto.*;
import za.co.vzap.email.SendForgotPassword;
import za.co.vzap.email.SendingEmail;
import za.co.vzap.logfile.LogFile;
import za.co.vzap.dao.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.io.*;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import net.sourceforge.jeuclid.context.Display;
public class ServerMain extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static JTextArea serverWindow;
	
	public ServerMain() {
		setTitle("Server");
		setLayout(new BorderLayout());
		serverWindow = new JTextArea();
		serverWindow.setLineWrap(true);
		serverWindow.setWrapStyleWord(true);
		add(serverWindow, BorderLayout.CENTER);
		setBackground(Color.GRAY);
		setBounds(600, 250, 600, 600);
		setPreferredSize(new Dimension(600, 600));
		setVisible(true);
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) 
	{
		new ServerMain();
		
		ServerSocket serverSocket = null;
		Socket clientSocket = null;

		try 
		{
			serverSocket = new ServerSocket(20000);
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		while(true)
			try 
		{
				System.out.println("Server waiting for client connection");
				ServerMain.display("Server waiting for client connection...");
				clientSocket = serverSocket.accept();
				ServerMain.display("Client Connected" + clientSocket.toString());
				new ThreadedServer(clientSocket, clientSocket.getInetAddress().toString()).start();

		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	public static void display(String message){
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				serverWindow.append(message + "\n");
				
			}
		});
	}

}

class ThreadedServer extends Thread
{
	private Socket socketFromAccept = null;
	private ObjectInputStream ois = null;
	private ObjectOutputStream oos = null;
	private MySqlReportDAO msrd = new MySqlReportDAO();
	private MySqlGeneralDAO msgd = new MySqlGeneralDAO();
	private String ip;
	private UserDTO user;

	public ThreadedServer(Socket socketFromAccept, String ip)
	{
		this.socketFromAccept = socketFromAccept;
		this.ip = ip;
	}

	public void run()
	{
		try
		{
			oos = new ObjectOutputStream(socketFromAccept.getOutputStream());
			ois = new ObjectInputStream(socketFromAccept.getInputStream());
			ClientDTO client = null;
			int choice = 0;
			while(choice != 16)
			{

				String choice1 = ois.readUTF();
				choice = Integer.parseInt(choice1);
				System.out.println("choice from client = " + choice);
				ServerMain.display("Client: "+ip+"chose ->" + choice);
				switch (choice) 
				{
				case 1: user = (UserDTO)(ois.readObject());

				ArrayList<BookingDTO> clientBookings = new ArrayList<BookingDTO>();
				try 
				{
					ArrayList<UserDTO> userList = (ArrayList<UserDTO>) msrd.userListAll();
					for(int uL = 0; uL < userList.size(); uL++)
					{
						if((user.getClientUsername().equals(userList.get(uL).getClientUsername())) && (user.getClientPassword().equals(userList.get(uL).getClientPassword())))
						{
							ArrayList<ClientDTO> clientList = (ArrayList<ClientDTO>)msrd.clientAll();
							int clientLength = clientList.size();
							for(int cL = 0; cL < clientLength; cL++)
							{
								if(userList.get(uL).getClientUsername().equals(clientList.get(cL).getClientEmail()))
								{							
									client = new ClientDTO(clientList.get(cL).getClientName(), clientList.get(cL).getClientSurname(), clientList.get(cL).getClientTitle(), clientList.get(cL).getClientPhoneNumber(), clientList.get(cL).getClientEmail(), clientList.get(cL).getDepartment(), clientList.get(cL).getPassword(), clientList.get(cL).getisExecutive());
									ArrayList<BookingDTO> bookingList = (ArrayList<BookingDTO>)msrd.bookingAll();
									int bookingLength = bookingList.size();
									for(int bL = 0; bL < bookingLength; bL++)
									{
										if((clientList.get(cL).getClientName().equals(bookingList.get(bL).getClientName())) || (clientList.get(cL).getClientSurname().equals(bookingList.get(bL).getClientSurname())))
										{
											BookingDTO booking = new BookingDTO(bookingList.get(bL).getClientName(), bookingList.get(bL).getClientSurname(), bookingList.get(bL).getStartDate(), bookingList.get(bL).getEndDate(), bookingList.get(bL).isBooked(), bookingList.get(bL).getRoomName(), bookingList.get(bL).getMeetingDescription(), bookingList.get(bL).getNumberOfAttendees());
											clientBookings.add(booking);
										}
									}
								}	
							}
						}
					}
					oos.writeObject(clientBookings);
					oos.flush();
					oos.writeObject(client);
					oos.flush();
					ServerMain.display(client.getClientName() + " logged in!");
				} 
				catch (SQLException e) 
				{
					ServerMain.display("Error: case1");
					e.printStackTrace();
				}
				break;

				case 2:	BookingDTO book = (BookingDTO)(ois.readObject());
				ServerMain.display("A booking has been made: " + book.getRoomName() + "\t" + book.getRoomName());
				//if it says waiting add to waiting list
				//if it says pending send email 
				// if it says booked continue
				try 
				{
					msgd.insertBooking(book);
					int size = ois.readInt();
					RoomEquipmentDTO re = (RoomEquipmentDTO)ois.readObject();
					while(size > 0)
					{
						if(re == null)
							break;
						msgd.insertRoomEquipment(re);
						System.out.println("Size = " + size + "\nEquipment = " + re.getRoomEquipment());
						size--;
						if(size < 1)
							break;
						re = (RoomEquipmentDTO)ois.readObject();

					}
					if(book.getBooked().equalsIgnoreCase("waiting"))
					{
						msgd.insertWaitingList(new WaitingListDTO(book.getClientName(), book.getClientSurname(), book.getRoomName(), book.getStartDate(), book.getEndDate(), true));
					}
					if(book.getBooked().equalsIgnoreCase("pending"))
					{
						new SendingEmail(client, book);
					}

				} 

				catch (SQLException e) 
				{
					ServerMain.display("Error: case2");
					e.printStackTrace();
				}
				break;

				case 3:	String text = (String) ois.readObject();
				try {
					ArrayList<Object> objectArray = new ArrayList<>();
					 msgd.findBooking(text);
					ArrayList<ClientDTO> clientThatBooked = new ArrayList<ClientDTO>();
					ArrayList<BookingDTO> bookingDetails  = new ArrayList<BookingDTO>();
					for(int i = 0 ; i < objectArray.size() ; i++)
					{
						if(i%2 == 0)
						{
							clientThatBooked.add((ClientDTO)objectArray.get(i));
						}
						if(i%2 != 0)
						{
							bookingDetails.add((BookingDTO) objectArray.get(i));
						}
					}

					oos.writeObject(clientThatBooked);
					oos.flush();
					oos.writeObject(bookingDetails );
					oos.flush();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				break;

				case 4: getStatsForGraphs();
				ServerMain.display("case 4");
				break;

				case 5:	ArrayList<RoomDTO> list = displayAvailableRooms(ois.readInt());
				oos.writeObject(list);
				oos.flush();
				oos.writeObject(getSpecializedBookings(list));
				oos.flush();


				break;
				case 6:	try 
				{
					String name = ois.readUTF();
					String surname = 	ois.readUTF();	
					String roomName = ois.readUTF();
					String date = ois.readUTF();
					msgd.updateBookingStatusCancel(name, surname, roomName, date);
					msgd.updateRoomCancels(roomName, date, name, surname);
					ServerMain.display("A booking was cancelled: " + roomName);
				} 
				catch (SQLException e) 
				{
					ServerMain.display("Error: case6");
					e.printStackTrace();
				}
				break;

				case 7: try 
				{
					msgd.insertClient((ClientDTO)ois.readObject());
				} 
				catch (SQLException e) 
				{
					ServerMain.display("Error: case7");
					e.printStackTrace();
				}
				break;
				case 8: try {
					oos.writeObject((ArrayList<RoomCancellationsDTO>)msrd.roomCancellationsListAll());
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
				break;
				case 9: try {
					oos.writeObject((ArrayList<WaitingListDTO>)msrd.waitingListAll());
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
				break;
				case 10: msgd.updateBookingStatusBooked(ois.readUTF(), ois.readUTF(), ois.readUTF(), ois.readUTF());
				break;	

				case 11: BookingDTO bookingUpdate = updateWaitlistPerson(ois.readUTF(), ois.readUTF());	
				if(bookingUpdate == null){
					break;
				}
				for(ClientDTO c : msrd.clientAll()){
					if(c.getClientName().equals(bookingUpdate.getClientName())){
						System.out.println(c);
						System.out.println(bookingUpdate);
						new SendingEmail(c, bookingUpdate);
					}
				}
				break;
				case 12: oos.writeObject(msrd.roomListAll());
				oos.flush();
				ArrayList<BookingDTO> temp = (ArrayList<BookingDTO>) msrd.bookingAll();
				ArrayList<BookingDTO> send = new ArrayList<>();
				for(BookingDTO b : temp){
					if(b.getBooked().equalsIgnoreCase("booked")){
						send.add(b);
					}
				}
				oos.writeObject(send);
				oos.flush();
				oos.writeObject(msrd.clientAll());
				oos.flush();
				break;
				case 13: LogFile lf = new LogFile(user, InetAddress.getByName(ip));
						break;
				case 14: System.out.println("In case14");
					int sw = ois.readInt();
				System.out.println(sw);
				String temp1 = "";
					if(sw == 1){
						temp1 = ois.readUTF();
						System.out.println(temp1);
						oos.writeObject(msrd.roomReportListWeekList(temp1));
					}
					if(sw == 2){
						temp1 = ois.readUTF();
						oos.writeObject(msrd.roomReportListMonthList(temp1));
					}
					if(sw == 3){
						temp1 = ois.readUTF();
						oos.writeObject(msrd.roomReportListYearList(temp1));
					}
					break;
				case 15: String email = ois.readUTF();
					for(ClientDTO cl : msrd.clientAll()){
						if(cl.getClientEmail().equals(email)){
							SendForgotPassword sfp = new SendForgotPassword(cl);
						}
					}
				}			
			}
			oos.close();
			ois.close();
		} 
		catch (IOException | ClassNotFoundException | SQLException e) 
		{
			ServerMain.display("Client has disconnected: " + ip + " " + user.getClientUsername());
			System.out.println("Client has disconnected...");
		}
	}
	private BookingDTO updateWaitlistPerson(String roomName, String date) {
		try {
			ArrayList<BookingDTO> allBookings = (ArrayList<BookingDTO>) msrd.bookingAll();
			for(BookingDTO b : allBookings){
				if(b.getBooked().equalsIgnoreCase("pending")){
					if(b.getRoomName().equals(roomName) && b.getStartDate().equals(date)){
						msgd.updateBookingStatusBooked(b.getClientName(), b.getClientSurname(), b.getRoomName(), b.getStartDate());
						return b;
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	private ArrayList<RoomDTO> displayAvailableRooms(int attendees) throws SQLException {
		ArrayList<RoomDTO> allRooms = (ArrayList<RoomDTO>) msrd.roomListAll();
		ArrayList<RoomDTO> criteria = new ArrayList<RoomDTO>();
		System.out.println(attendees);
		for(int i = 0; i < allRooms.size(); i++){
			if(6>attendees && attendees>1 && (allRooms.get(i).getRoomCapacity() == 5 || allRooms.get(i).getRoomCapacity() == 10) ){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
			if(11>attendees && attendees>5 && (allRooms.get(i).getRoomCapacity() == 10 || allRooms.get(i).getRoomCapacity() == 15)){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
			if(16>attendees && attendees>10 && (allRooms.get(i).getRoomCapacity() == 15 || allRooms.get(i).getRoomCapacity() == 20)){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
			if(21>attendees && attendees>15 && (allRooms.get(i).getRoomCapacity() == 20 || allRooms.get(i).getRoomCapacity() == 25)){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
			if(26>attendees && attendees>20 && (allRooms.get(i).getRoomCapacity() == 25 || allRooms.get(i).getRoomCapacity() == 30)){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
			if(31>attendees && attendees>25 && allRooms.get(i).getRoomCapacity() == 30){
				criteria.add(allRooms.get(i));
				System.out.println(allRooms.get(i));
			}
		}
		return criteria;
	}

	private ArrayList<BookingDTO> getSpecializedBookings(ArrayList<RoomDTO> criteria) throws SQLException {
		ArrayList<BookingDTO> allBookings = (ArrayList<BookingDTO>) msrd.bookingAll();
		ArrayList<BookingDTO> bookings = new ArrayList<BookingDTO>();
		for(int i = 0; i < allBookings.size(); i++){
			for(int j = 0; j < criteria.size(); j++){
				if(allBookings.get(i).getRoomName().equals(criteria.get(j).getRoomName())){
					bookings.add(allBookings.get(i));
				}
			}	
		}
		return bookings;
	}



	public void getStatsForGraphs(){
		try {
			ArrayList<RoomDTO> roomUseStats = (ArrayList<RoomDTO>) msrd.roomListAll();
			ArrayList<RoomCancellationsDTO> roomCancelStats = (ArrayList<RoomCancellationsDTO>) msrd.roomCancellationsListAll();		
			ArrayList<RoomEquipmentDTO> equipmentStats = (ArrayList<RoomEquipmentDTO>) msrd.roomEquipmentListAll();
			ArrayList<BookingDTO> bookings = (ArrayList<BookingDTO>) msrd.bookingAll();
			oos.writeObject(roomUseStats);
			oos.flush();

			oos.writeObject(roomCancelStats);
			oos.flush();

			oos.writeObject(equipmentStats);
			oos.flush();
			
			oos.writeObject(bookings);
			oos.flush();
			System.out.println("Finish write!");
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
	}
}

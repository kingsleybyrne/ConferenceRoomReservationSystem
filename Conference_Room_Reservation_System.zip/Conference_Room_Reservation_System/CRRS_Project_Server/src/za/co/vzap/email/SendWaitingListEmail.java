package za.co.vzap.email;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.ClientDTO;

public class SendWaitingListEmail {
	private Properties properties;
	
	public SendWaitingListEmail(ClientDTO client,BookingDTO booking){
		properties=new Properties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");
		
		String authenticateUsername="vzapreservationsystem@gmail.com";
		String authenticatePassword="vzap123@";
		String fromEmail="vzapreservationsystem@gmail.com";
		String subject="Conference Room Booking Confirmation";
		String emailMessage="Dear "+client.getClientName()+",<br />You are on the waiting list for,<br /><br />Room:<t /> "+booking.getRoomName()+" room<br />From:<t /> <style> body{color: red"+booking.getStartDate()+"<br />To:<t /> "+booking.getEndDate()+"}</style><br />Description:<t /> "+booking.getMeetingDescription()+""
				+ "<br /><br />Thank you,"
				+ "<br />Conference Room Reservation System</ br>";
		Session session=Session.getDefaultInstance(properties, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication(){
				return new PasswordAuthentication(authenticateUsername,authenticatePassword);
			}
		});
		
	         try {
				Message message = new MimeMessage(session);
				 //long sentTime=message.getSentDate().getTime();
				 message.setFrom(new InternetAddress(fromEmail));
				 message.setRecipients(Message.RecipientType.TO,
				    InternetAddress.parse(client.getClientEmail()));
				 message.setSubject(subject);
				 MimeMultipart multipart = new MimeMultipart("related");
				 BodyPart messageBodyPart = new MimeBodyPart();
				 String htmlText = "<H1>"+emailMessage+"</H1>"+"</ br></ br><H2><img src=\"cid:image\"><H2 />";
				 messageBodyPart.setContent(htmlText, "text/html");
				 multipart.addBodyPart(messageBodyPart);
				 messageBodyPart = new MimeBodyPart();
				 DataSource fds = new FileDataSource(
				    "resources/new logo.png");

				 messageBodyPart.setDataHandler(new DataHandler(fds));
				 messageBodyPart.setHeader("Content-ID", "<image>");
				 multipart.addBodyPart(messageBodyPart);
				 message.setContent(multipart);
				 Transport.send(message);

				 System.out.println("Sent message successfully....");
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}

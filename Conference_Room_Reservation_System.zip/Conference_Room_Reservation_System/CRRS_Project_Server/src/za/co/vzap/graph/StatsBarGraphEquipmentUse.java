package za.co.vzap.graph;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import za.co.vzap.dao.MySqlReportDAO;

import za.co.vzap.dto.RoomEquipmentDTO;

public class StatsBarGraphEquipmentUse extends ApplicationFrame {
	private static final long serialVersionUID = 1L;

	public StatsBarGraphEquipmentUse() throws SQLException, IOException {
		super( "Equipment Use Statistics" );
		String chartTitle="Equipment Use Statistics";
	      JFreeChart barChart = ChartFactory.createBarChart(
	         chartTitle,           
	         "Equipment",            
	         "Uses",            
	         createDataset(),          
	         PlotOrientation.VERTICAL,           
	         true, true, false);
	         
	      ChartPanel chartPanel = new ChartPanel( barChart );        
	      chartPanel.setPreferredSize(new java.awt.Dimension( 1200 , 800 ) );        
	      setContentPane( chartPanel ); 
	      this.pack( );        
			RefineryUtilities.centerFrameOnScreen( this ); 
			File pieChart = new File( "resources/StatsEquipmentUseBarChart.jpeg" ); 
		    int width = 640;   /* Width of the image */
		    int height = 480; 
		    ChartUtilities.saveChartAsJPEG( pieChart , barChart , width , height );
			this.setVisible( true ); 
	}
	 private CategoryDataset createDataset( ) throws SQLException {
	      
	      MySqlReportDAO listDAO =new MySqlReportDAO();
		  ArrayList<RoomEquipmentDTO> equipmentList=(ArrayList<RoomEquipmentDTO>)listDAO.roomEquipmentListAll();
		  
		  final DefaultCategoryDataset dataset = 
			      new DefaultCategoryDataset( );  
		  
		  for(int i=0;i<equipmentList.size();i++){
			  dataset.addValue(equipmentList.get(i).getEquipmentQuantity(),equipmentList.get(i).getRoomEquipment(), "Usage");
		  }             

	      return dataset; 
	   }
//	 public static void main( String[ ] args ) {
//	      StatsBarGraphEquipmentUse chart;
//		try {
//			chart = new StatsBarGraphEquipmentUse();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	   }
}

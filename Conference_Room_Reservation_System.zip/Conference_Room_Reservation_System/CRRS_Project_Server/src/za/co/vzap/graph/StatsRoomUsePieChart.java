package za.co.vzap.graph;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import za.co.vzap.dao.MySqlReportDAO;
import za.co.vzap.dto.RoomDTO;

public class StatsRoomUsePieChart extends ApplicationFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatsRoomUsePieChart() throws SQLException{
		super("Buidling Use");
		setContentPane(createDemoPanel( ));
		this.setSize( 1200 , 900 );    
		RefineryUtilities.centerFrameOnScreen( this ); 
		this.setVisible( true ); 
	}
	private static PieDataset createDataset() throws SQLException {
		DefaultPieDataset dataset = new DefaultPieDataset( );
		MySqlReportDAO listDao = new MySqlReportDAO();
		ArrayList<RoomDTO> roomList = (ArrayList<RoomDTO>)listDao.roomListAll();
		
		int count=0;
		for(int i=0;i<roomList.size();i++){
			if(roomList.get(i).getBuildingName().equals("North")){
				count=0;
				count=count+roomList.get(i).getRoomCount();
				dataset.setValue(roomList.get(i).getBuildingName(), new Double(count));
			}
			if(roomList.get(i).getBuildingName().equals("South")){
				count=0;
				count=count+roomList.get(i).getRoomCount();
				dataset.setValue(roomList.get(i).getBuildingName(), new Double(count));
			}
			if(roomList.get(i).getBuildingName().equals("East")){
				count=0;
				count=count+roomList.get(i).getRoomCount();
				dataset.setValue(roomList.get(i).getBuildingName(), new Double(count));
			}
			if(roomList.get(i).getBuildingName().equals("West")){
				count=0;
				count=count+roomList.get(i).getRoomCount();
				dataset.setValue(roomList.get(i).getBuildingName(), new Double(count));
			}
			//dataset.setValue(roomList.get(i).getBuildingName(), new Double(roomList.get(i).getRoomCount()));
		}

		return dataset;         
	}

	private static JFreeChart createChart( PieDataset dataset ) throws IOException {
		JFreeChart chart = ChartFactory.createPieChart(      
				"Building Use",   // chart title 
				dataset,          // data    
				true,             // include legend   
				true, 
				false);
		File pieChart = new File( "resources/StatsRoomUsePieChart.jpeg" ); 
		int width = 640;   /* Width of the image */
		int height = 480; 
		ChartUtilities.saveChartAsJPEG( pieChart , chart , width , height );
		return chart;
	}

	public static JPanel createDemoPanel( ) throws SQLException {
		JFreeChart chart = null;
		try {
			chart = createChart(createDataset( ) );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return new ChartPanel( chart ); 
	}

		public static void main( String[ ] args ) {
			try {
				StatsRoomUsePieChart demo = new StatsRoomUsePieChart();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		}

}

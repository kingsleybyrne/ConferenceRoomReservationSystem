package za.co.vzap.client;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EquipmentReport extends JPanel {
	private JPanel equipmentReportPanel;
	private JPanel nPanel;
	private JLabel lblEquipmentReport;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton btnViewEquipmentChart;
	public static EquipmentReport er = new EquipmentReport();
	private JButton return2ReportBtn;

	/**
	 * Create the panel.
	 */
	public EquipmentReport() {
		setBackground(Color.PINK);
		
		equipmentReportPanel = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(equipmentReportPanel, GroupLayout.DEFAULT_SIZE, 775, Short.MAX_VALUE)
					.addGap(0))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(equipmentReportPanel, GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
					.addGap(0))
		);
		
		nPanel = new JPanel();
		nPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		scrollPane = new JScrollPane();
		
		btnViewEquipmentChart = new JButton("View Equipment Chart");
		btnViewEquipmentChart.addActionListener(e->{
			try {
				Controller.getInstance().displayEquipmentChart();
			} catch (ClassNotFoundException | SQLException | IOException e1) {
				
				e1.printStackTrace();
			}
		});
		
		return2ReportBtn = new JButton("> Return to Report Page");
		return2ReportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayReportPage();
			}
		});
		GroupLayout gl_equipmentReportPanel = new GroupLayout(equipmentReportPanel);
		gl_equipmentReportPanel.setHorizontalGroup(
			gl_equipmentReportPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_equipmentReportPanel.createSequentialGroup()
					.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 190, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(532, Short.MAX_VALUE))
				.addGroup(gl_equipmentReportPanel.createSequentialGroup()
					.addGap(252)
					.addComponent(btnViewEquipmentChart)
					.addContainerGap(333, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_equipmentReportPanel.createSequentialGroup()
					.addContainerGap(117, Short.MAX_VALUE)
					.addGroup(gl_equipmentReportPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(return2ReportBtn)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 493, GroupLayout.PREFERRED_SIZE))
					.addGap(112))
		);
		gl_equipmentReportPanel.setVerticalGroup(
			gl_equipmentReportPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_equipmentReportPanel.createSequentialGroup()
					.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addGap(32)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
					.addGap(31)
					.addComponent(btnViewEquipmentChart)
					.addGap(28)
					.addComponent(return2ReportBtn)
					.addContainerGap(108, Short.MAX_VALUE))
		);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"AirCon", null},
				{"Chair", null},
				{"Clock", null},
				{"Coffee", null},
				{"Complimentary Treats", null},
				{"Computer Mouse", null},
				{"Extension Cable", null},
				{"Fan", null},
				{"HDMI Cable", null},
				{"Heater", null},
				{"Kettle", null},
				{"Laptop", null},
				{"Large Table", null},
				{"Laser Pointer", null},
				{"Medium Table", null},
				{"Microphone", null},
				{"Microphone Stand", null},
				{"Mugs", null},
				{"Network Cable", null},
				{"Notepad", null},
				{"PA System", null},
				{"Pen", null},
				{"Projector", null},
				{"Slide Projector", null},
				{"Small Table", null},
				{"Sound Amplifier", null},
				{"Speaker", null},
				{"Tape Recorder", null},
				{"Tea", null},
				{"Telivision", null},
				{"Video Cassette Recorder", null},
				{"Water Bottle", null},
				{"White Board", null},
			},
			new String[] {
				"Equipment", "Times Used"
			}
		));
		
		lblEquipmentReport = new JLabel("Equipment Report");
		lblEquipmentReport.setFont(new Font("Tahoma", Font.BOLD, 15));
		GroupLayout gl_nPanel = new GroupLayout(nPanel);
		gl_nPanel.setHorizontalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_nPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblEquipmentReport)
					.addContainerGap(130, Short.MAX_VALUE))
		);
		gl_nPanel.setVerticalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_nPanel.createSequentialGroup()
					.addGap(20)
					.addComponent(lblEquipmentReport)
					.addContainerGap(20, Short.MAX_VALUE))
		);
		nPanel.setLayout(gl_nPanel);
		equipmentReportPanel.setLayout(gl_equipmentReportPanel);
		setLayout(groupLayout);

	}
	public JPanel returnEquipmentReport() {
		return er;
	}

}

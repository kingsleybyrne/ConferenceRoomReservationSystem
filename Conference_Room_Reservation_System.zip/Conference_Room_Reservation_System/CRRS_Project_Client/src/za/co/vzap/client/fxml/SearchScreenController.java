package za.co.vzap.client.fxml;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javax.swing.JButton;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.ClientDTO;
import za.co.vzap.dto.RoomDTO;

public class SearchScreenController implements Initializable {
	@FXML
	private ImageView image;
	@FXML
	private JFXButton nile;
	@FXML
	private JFXButton zambezi;
	@FXML
	private JFXButton amazon;
	@FXML
	private JFXButton ganges;
	@FXML
	private JFXButton rhine;
	@FXML
	private JFXButton missi;
	@FXML
	private JFXButton mosman;
	@FXML
	private JFXButton ottawa;
	@FXML
	private JFXButton ebro;
	@FXML
	private JFXButton congo;
	@FXML
	private JFXButton thames;
	@FXML
	private JFXButton seine;
	@FXML
	private MenuItem menuHome;
	@FXML
	private MenuItem menuClose;
	@FXML
	private MenuItem menuQuestionnaire;
	@FXML
	private MenuItem menuSearch;
	@FXML
	private MenuItem menuReports;
	@FXML
	private MenuItem menuHelp;
	@FXML
	private JFXButton gotoHome;
	@FXML
	private JFXTextField roomName;
	@FXML
	private JFXTextArea description;
	@FXML
	private JFXTextField capacity;
	@FXML
	private JFXTextField personName;
	@FXML
	private JFXTextField meetingDescription;
	@FXML
	private JFXTextField attendees;
	private ArrayList<RoomDTO> rooms;
	private ArrayList<BookingDTO> bookings;
	private DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	private boolean client = ClientFX.getInstance().getClient().getisExecutive();
	private boolean setBool;
	
	
	
	
	public void gotoHomeScreen(){
		MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
	}
	
	public void dispAmazon(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			
			
			
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("amazon")){
					roomName.setText(r.getRoomName());
					description.setText("The Amazon conference room is Located on the third floor of the North buliding, this room features many A/V equipment for projecting"
+ " from your laptop or mobile device. The Amazon is a bright and airy space perfect for mid-sized meetings" +
" with a seating capacity of 10 round the table."
					);
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("amazon")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
						
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispCongo(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Congo")){
					roomName.setText(r.getRoomName());
					description.setText("The Congo conference room. Inspired from the name, this room give you that nature feel with its wild but modern"
+" look to the room, the oak furniture and green look allows you and your clients to conduct your meeting" 
+" in a relaxed environment. this room has a seating capacity of 15 in the West building."
);
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Congo")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispEbro(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Ebro")){
					roomName.setText(r.getRoomName());
					description.setText("The Ebro room. Large windows brighten the finely appointed space, offering a panorama of lush woods and" 
+" greenery, and creating a pleasingly open and relaxing environment. The 15-seat room is located in"
+" the East building.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Ebro")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispGanges(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Ganges")){
					roomName.setText(r.getRoomName());
					description.setText("The Ganges room. This 20 seater room in the East building offers modern furniture and state of the art"
+" technology to assist the conference meetings and think tanks. This room offers numerous standard A/V"
+" equipment as well as high speed internet connectivity."
);
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Ganges")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispMosman(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Mosman")){
					roomName.setText(r.getRoomName());
					description.setText("The Mosman room. A semi large high tech board room with a maximum seating capacity of 20 round the table."
+ " This room features floor to ceiling windows with a great view of the property golf course outside.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Mosman")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispMissi(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Missisippi")){
					roomName.setText(r.getRoomName());
					description.setText("The Missisippi boardroom. This newly renovated room features a sleek conference table and plush"
+" seating for 10. With its very own flat screen monitor, whiteboard  and wireless printer/scanner,"
+" this room is perfect for board meetings and executive retreats.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Missisippi")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispNile(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Nile")){
					roomName.setText(r.getRoomName());
					description.setText("The Nile. Appointed with soft seating and a conference table for 20, this room is great for structured sessions" 
							+" or medium, intimate groups looking for flexible space. This room is located in the North building."
							+" A/V equipment available for use in the room.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Nile")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispOttawa(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Ottawa")){
					roomName.setText(r.getRoomName());
					description.setText("The Ottawa. Our largest conference room, with 1140 flexible square feet and a seating capacity of 30 round the boardroom table," 
+" This room is located at the lobby level in the East building." 
+" Ottawa is outfitted with modern meeting equipment and supplies.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Ottawa")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispRhine(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Rhine")){
					roomName.setText(r.getRoomName());
					description.setText("The Rhine room. The second of the largest conference rooms in the West building with space for additional clients"
+" to be held comfortably. This room has an average capacity of 30. featuring high tech Equipment and awesome snacks,"
+" this is where you want to launch your newest software!"
);
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Rhine")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispSeine(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Seine")){
					roomName.setText(r.getRoomName());
					description.setText("The Seine is located on the second floor in the South building of the property. The Seine Conference room was reinvented for"
+" today's large-sized groups. The room features traditional Tudor-styling, large picture windows, and a sun porch which can function as a separate"
+" break out area for smaller group sessions or casual conversation. The seating capacity for this room is 25.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Seine")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispThames(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Thames")){
					roomName.setText(r.getRoomName());
					description.setText("The Thames room. Similar to the Zambezi room, this light and bright third-floor room located in"
+" the South building, features a flat-screen monitor and is great for small meetings.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Thames")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void dispZambezi(){
		try {
			roomName.setText("");
			description.setText("");
			capacity.setText("");
			personName.setText("");
			meetingDescription.setText("");
			attendees.setText("");
			
			Date date = formatter.parse(formatter.format(new Date()));
			for(RoomDTO r : rooms){
				if(r.getRoomName().equalsIgnoreCase("Zambezi")){
					roomName.setText(r.getRoomName());
					description.setText("The Zambezi conference room, located on the second floor of the North side of the"
+" property, features a charming original fireplace, floor to ceiling windows, and a flat-screen" 
+" monitor for projecting right from a laptop or other mobile device. This room is well-suited for" 
+" meetings, executive conferences, and social events alike with its smaller searing capacity of 5.");
					capacity.setText(String.valueOf(r.getRoomCapacity()));
					if(r.getRoomCapacity() == 5){
						image.setImage(new Image(getClass().getResource("5.jpg").toString()));
					}
					if(r.getRoomCapacity() == 10){
						image.setImage(new Image(getClass().getResource("10.jpg").toString()));	
					}
					if(r.getRoomCapacity() == 15){
						image.setImage(new Image(getClass().getResource("15.jpg").toString()));
					}
					if(r.getRoomCapacity() == 20){
						image.setImage(new Image(getClass().getResource("20.jpg").toString()));
					}
					if(r.getRoomCapacity() == 30){
						image.setImage(new Image(getClass().getResource("30.jpg").toString()));
					}
				}
			}
			for(BookingDTO b : bookings){
				if(b.getRoomName().equalsIgnoreCase("Zambezi")){
					Date d1 = formatter.parse(b.getStartDate());
					if(d1.equals(date) || d1.after(date)){
						for(ClientDTO c : ClientFX.getInstance().getClientThatBooked()){
							if(b.getClientName().equals(c.getClientName())){
								if(c.isExecutive() && client){
									setBool = true;
								} else {
									if(client && !c.isExecutive()){
										setBool = true;
									} else {
										setBool = false;
									}
								}
							}
						}
						if(setBool){
							personName.setText(b.getClientName() + " " + b.getClientSurname());
							meetingDescription.setText(b.getMeetingDescription());
							attendees.setText(String.valueOf(b.getNoOfAttendees()));
						} else {
							meetingDescription.setText("Room Unavailable");
						}
					} else {
						meetingDescription.setText("No Current Bookings");
					}
				} else {
					meetingDescription.setText("No Current Bookings");
				}
			}
		} catch (ParseException e) {
			 // Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ClientFX.getInstance().allRooms();
		rooms = ClientFX.getInstance().getAllRooms();
		bookings = ClientFX.getInstance().getAllbookings();
		
		roomName.setEditable(false);
		description.setEditable(false);
		capacity.setEditable(false);
		personName.setEditable(false);
		meetingDescription.setEditable(false);
		attendees.setEditable(false);
	}
	
	public void closeTheProgram(){
		MainStage.getStage().close();
		System.exit(0);
	}
	public void gotoQuestionnaireScreen() throws IOException{		
			MainStage.getStage().setScene(HomeScreenController.getQuestionnaireScreen());
	}
	public void gotoSearchScreen() throws IOException{
		
		MainStage.getStage().setScene(HomeScreenController.getSearchScreen());
	}
	public void gotoReports() throws IOException{
		MainStage.getStage().setScene(HomeScreenController.getReportsScreen());
	}
	public void displayHelp(){
		
	}
}

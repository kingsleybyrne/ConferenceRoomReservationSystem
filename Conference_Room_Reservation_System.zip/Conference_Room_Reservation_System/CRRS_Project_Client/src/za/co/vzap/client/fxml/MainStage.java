package za.co.vzap.client.fxml;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainStage extends Application {

	private static Stage frame;
	private static Scene root;
	
	
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		frame = primaryStage;
		Parent proot = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
		
				
		
		
		
		root = new Scene(proot);
		
		
		
		
		
		
		frame.setScene(root);
		frame.setTitle("Reservation System");
		frame.show();
	}
	
	public static Stage getStage(){
		return frame;
	}
	
	public static Scene getLoginScreen(){
		return root;
	}
	
	
	
	

	
	
}

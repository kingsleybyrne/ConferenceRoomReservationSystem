package za.co.vzap.client.fx;

import java.util.ArrayList;

public class WaitlistStats {
	private String userName;
	private String roomName;
	private String time;
	private ArrayList<String> equipment;
	/**
	 * @param userName
	 * @param roomName
	 * @param time
	 * @param equipment
	 */
	public WaitlistStats(String userName, String roomName, String time, ArrayList<String> equipment) {
		super();
		this.userName = userName;
		this.roomName = roomName;
		this.time = time;
		this.equipment = equipment;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the roomName
	 */
	public String getRoomName() {
		return roomName;
	}
	/**
	 * @param roomName the roomName to set
	 */
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the equipment
	 */
	public ArrayList<String> getEquipment() {
		return equipment;
	}
	/**
	 * @param equipment the equipment to set
	 */
	public void setEquipment(ArrayList<String> equipment) {
		this.equipment = equipment;
	}
	
	
}

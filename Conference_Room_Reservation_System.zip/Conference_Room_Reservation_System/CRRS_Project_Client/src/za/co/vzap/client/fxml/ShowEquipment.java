package za.co.vzap.client.fxml;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.EquipmentDTO;
import za.co.vzap.dto.RoomEquipmentDTO;
import za.co.vzap.dto.WaitingListDTO;

public class ShowEquipment {

	public static void displayWith(BookingDTO current) throws ClassNotFoundException, IOException {
		Stage window = new Stage();
		window.setTitle("Display Equipment");
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent t) {
		        window.close();
		        
		    }
		});
		
		window.initModality(Modality.APPLICATION_MODAL);
		TableView<EquipmentDTO> equipmentTable = new TableView<>();
		equipmentTable.setPrefSize(200.0, 400.0);
		TableColumn<EquipmentDTO, String> equipmentNameColumn = new TableColumn<>("Equipment Name");
		equipmentNameColumn.setMinWidth(200);
		equipmentNameColumn.setCellValueFactory(new PropertyValueFactory<>("equipmentName"));
		for(RoomEquipmentDTO booking : ClientFX.getInstance().getRoomEquipmentStats()){
			if(booking.getClientName().equals(current.getClientName())&&booking.getRoomName().equals(current.getRoomName())){
				equipmentTable.getItems().add(new EquipmentDTO(booking.getRoomEquipment()));
			}
		}

		equipmentTable.getColumns().add(equipmentNameColumn);
		BorderPane layout = new BorderPane();
		layout.setCenter(equipmentTable);
		Scene s = new Scene(layout);
		window.setScene(s);
		window.showAndWait();
	}

}

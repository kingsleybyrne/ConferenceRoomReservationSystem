package za.co.vzap.client.fxml;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.jfoenix.concurrency.JFXUtilities;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.print.PrinterJob;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.client.fx.AddEquip;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.ClientDTO;

public class QuestionnaireScreenController implements Initializable{
	@FXML
	private MenuItem menuHome;
	@FXML
	private MenuItem menuClose;
	@FXML
	private MenuItem menuQuestionnaire;
	@FXML
	private MenuItem menuSearch;
	@FXML
	private MenuItem menuReports;
	@FXML
	private MenuItem menuHelp;
	@FXML
	private ImageView image;
	@FXML
	public Label nameLbl, titleLbl, cellNoLbl, deptLbl, emailLbl;
	@FXML
	public JFXComboBox<String> noOfAtt;
	@FXML
	private JFXComboBox<String> startTime;
	@FXML
	private JFXComboBox<String> endTime;
	@FXML
	private JFXComboBox<String> equipment;
	@FXML
	private JFXComboBox<String> quantity;
	@FXML
	private DatePicker startDate, endDate;
	@FXML
	private TableView<AddEquip> equipmentTable;
	@FXML
	private JFXButton searchBTN, clearBTN;
	private static Scene bookingScreen;
	public int count = 0 ;
	
	public List<String> equipmentList;
	public List<String> quantityList;
	
	
	public QuestionnaireScreenController(){

	}
	
	public void test(){
		JFXUtilities.runInFX(new Runnable() {
			
			@Override
			public void run() {
				nameLbl.setText(ClientFX.getInstance().getClient().getClientName());
				titleLbl.setText(ClientFX.getInstance().getClient().getClientTitle());
				cellNoLbl.setText(ClientFX.getInstance().getClient().getClientPhoneNumber());
				deptLbl.setText(ClientFX.getInstance().getClient().getDepartment());
				emailLbl.setText(ClientFX.getInstance().getClient().getClientEmail());
			}
		});
	}
	
	
	public void verifyEndTime(){
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
			if(startTime.getSelectionModel().getSelectedItem() != null && endTime.getSelectionModel().getSelectedItem() != null){
				Date timeStart = formatter.parse(startTime.getSelectionModel().getSelectedItem());
				Date timeEnd = formatter.parse(endTime.getSelectionModel().getSelectedItem());
				if(timeStart.after(timeEnd) || timeEnd.before(timeStart)){
					int b = AlertBox.showErrorDialogue("Start Time can not be AFTER End Time! ", "Ok");
					if(b == 0){
						startTime.setValue(null);
						endTime.setValue(null);
					}
				}
				if(timeStart.equals(timeEnd)){
					int b = AlertBox.showErrorDialogue("Start and End Time can not be the same!", "Ok");
					if(b == 0){
						startTime.setValue(null);
						endTime.setValue(null);
					}
					startTime.setValue(null);
					endTime.setValue(null);

				}
			} else {
				AlertBox.showErrorDialogue("Start and End Time can not be empty! ", "Ok");
				
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	public void verifyStartTime(){
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
			
			if(startTime.getSelectionModel().getSelectedItem() != null && endTime.getSelectionModel().getSelectedItem() != null){
				Date timeStart = formatter.parse(startTime.getSelectionModel().getSelectedItem());
				Date timeEnd = formatter.parse(endTime.getSelectionModel().getSelectedItem());
				if(timeStart.after(timeEnd) || timeEnd.before(timeStart)){
					int b = AlertBox.showErrorDialogue("Start Time can not be AFTER End Time! ", "Ok");
					if(b == 0){
						startTime.setValue(null);
						endTime.setValue(null);
					}
				}
				if(timeStart.equals(timeEnd)){
					int b = AlertBox.showErrorDialogue("Start and End Time can not be the same!", "Ok");
					if(b == 0){
						startTime.setValue(null);
						endTime.setValue(null);
					}
					startTime.setValue(null);
					endTime.setValue(null);

				}
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	public void verifyStartDate(){
		LocalDate dateStart = startDate.getValue();
		LocalDate dateEnd = endDate.getValue();
		if(dateEnd!=null&&dateStart!=null){
			if(dateEnd.isBefore(dateStart)){
				AlertBox.showErrorDialogue("Selected end date can not be before start date!", "Ok");
				endDate.setValue(null);
			}
		}
		if(dateStart != null){
			Date current = new Date();
			LocalDate currendDate = current.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			if(dateStart.isBefore(currendDate)){
				int b = AlertBox.showErrorDialogue("Your selected start date can not be before current date\nPlease select a different date", "Ok");
				if(b == 0){
					startDate.setValue(null);
					
				}
			}
		}
	}
	public void verifyEndDate(){
		LocalDate dateStart = startDate.getValue();

		LocalDate dateEnd = endDate.getValue();
		
		if(dateStart != null && dateEnd != null){
			if(dateStart.isAfter(dateEnd) || dateEnd.isBefore(dateStart)){
				int b = AlertBox.showErrorDialogue("Start Date can not be AFTER End Date! ", "Ok");
				if(b == 0){
					startDate.setValue(null);
					endDate.setValue(null);
				}
			}
		} 
		
		
	}
	public void setTable(){
		count++;
		if(count == 1)
		{
			equipmentTable.getItems().clear();
		}
		String equip = equipment.getSelectionModel().getSelectedItem();
		String quant = quantity.getSelectionModel().getSelectedItem();
		equipmentTable.getItems().add(new AddEquip(equip, quant));
	}
	
	public void removeFromTable(){
		ObservableList<AddEquip> selected, allEquipments;
		allEquipments = equipmentTable.getItems();
		selected = equipmentTable.getSelectionModel().getSelectedItems();
		if(!equipmentTable.getSelectionModel().getSelectedItem().getT().equals("-")){
			int b = AlertBox.display("Remove?", "do you wish to remove this item?", "Yes", "No");
			if(b == 0){
				selected.forEach(allEquipments::remove);
				checkIfTableHasData();
			}
		}
	}
	
	public void search(){
		try {
			if(startDate.getValue() == null || endDate.getValue() == null || noOfAtt.getValue()==null || startTime.getValue()==null || endTime.getValue()==null){
				AlertBox.showErrorDialogue("Please Fill in all required Fields", "Ok");			
			} else {
				BookingScreenController.setTimes(startTime.getSelectionModel().getSelectedItem(),endTime.getSelectionModel().getSelectedItem());
				BookingScreenController.setAtt(noOfAtt.getSelectionModel().getSelectedItem());
				BookingScreenController.setDates(startDate.getValue(), endDate.getValue());
				BookingScreenController.setList(equipmentTable.getItems());
				Parent pbookingScreen = FXMLLoader.load(getClass().getResource("BookingScreen.fxml"));
				bookingScreen = new Scene(pbookingScreen);
				MainStage.getStage().setScene(bookingScreen);
			}				
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static Scene getBookingScreen(){
		return bookingScreen;
	}
	public void clearAll(){
		
		noOfAtt.setValue(null);
		startTime.setValue(null);
		endTime.setValue(null);
		startDate.setValue(null);
		endDate.setValue(null);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		createTable();
		setNoOfAttendees();
		test();
		setEndTimes();
		setStartTimes();
		setEquipments();
	}
	@SuppressWarnings("unchecked")
	private void createTable() {
		TableColumn<AddEquip, String> nameColumn = new TableColumn<>("Equipment");
		nameColumn.setMinWidth(400);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("s"));
		nameColumn.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> { 
			removeFromTable();
		});
		TableColumn<AddEquip, String> nextColumn = new TableColumn<>("Quantity");
		nextColumn.setMinWidth(200);
		nextColumn.setCellValueFactory(new PropertyValueFactory<>("t"));
		equipmentTable.getColumns().addAll(nameColumn, nextColumn);
		equipmentTable.addEventHandler(MouseEvent.MOUSE_CLICKED,  e -> { 
			removeFromTable();
		});
		checkIfTableHasData();
	}
	public void checkIfTableHasData()
	{
		if(equipmentTable.getItems().isEmpty()){			
			equipmentTable.getItems().add(new AddEquip("No Equipment Selected", "-"));
			count = 0;
		}
	}
	
	private void setNoOfAttendees() {
		if(noOfAtt!=null){
			noOfAtt.getItems().clear();
			noOfAtt.getItems().addAll("2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30");
		
		} else {
			noOfAtt.getItems().addAll("2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30");

		}
	}

	private void setEquipments() {
		if(quantity!=null){
			quantity.getItems().clear();
			quantity.getItems().addAll("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30");
		
		} else {
			quantity.getItems().addAll("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30");

		}
		if(equipment!=null){
			equipment.getItems().clear();
			equipment.getItems().addAll(
					"AirCon"										
					,"Computer Mouse"
					,"Extenstion Cable"
					,"Fan"
					,"HDMI Cable"
					,"Heater"
					,"Kettle"										
					,"Microphone"
					,"Microphone Stand"					
					,"Network Cable"					
					,"PA System"					
					,"Projector"
					,"Slide Projector"					
					,"Sound Amplifier"
					,"Speaker"
					,"Tape Recorder"					
					,"Television"
					,"Video Cassette Recorder"					
					,"White Board"
			);		
			
		} else {
			equipment.getItems().addAll(
					"AirCon"										
					,"Computer Mouse"
					,"Extenstion Cable"
					,"Fan"
					,"HDMI Cable"
					,"Heater"
					,"Kettle"										
					,"Microphone"
					,"Microphone Stand"					
					,"Network Cable"					
					,"PA System"					
					,"Projector"
					,"Slide Projector"					
					,"Sound Amplifier"
					,"Speaker"
					,"Tape Recorder"					
					,"Television"
					,"Video Cassette Recorder"					
					,"White Board"
					);		
		}
	}

	private void setStartTimes() {
		if(startTime.getItems().isEmpty()){
			startTime.getItems().addAll("08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30",
					"14:00","14:30","15:00","15:30","16:00","16:30");
		} else {
			startTime.getItems().clear();
			startTime.getItems().addAll("08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30",
					"14:00","14:30","15:00","15:30","16:00","16:30");
		}
		
	}
	
	private void setEndTimes() {
		if(endTime.getItems().isEmpty()){
			endTime.getItems().addAll("08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30",
					"14:00","14:30","15:00","15:30","16:00","16:30","17:00");
		} else {
			endTime.getItems().clear();
			endTime.getItems().addAll("08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30",
					"14:00","14:30","15:00","15:30","16:00","16:30","17:00");
		}
	}	
	public void gotoHomeScreen(){
		MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
	}
	public void closeTheProgram(){
		MainStage.getStage().close();
		System.exit(0);
	}
	public void gotoQuestionnaireScreen() throws IOException{		
		
	}
	public void gotoSearchScreen() throws IOException{
		
		MainStage.getStage().setScene(HomeScreenController.getSearchScreen());
	}
	public void gotoReports() throws IOException{
		MainStage.getStage().setScene(HomeScreenController.getReportsScreen());
	}
	public void displayHelp(){
		
	}	
}

package za.co.vzap.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Vector;

import javax.swing.*;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.toedter.calendar.JCalendar;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;

public class MainMenu implements ListSelectionListener{
	private JPanel mainPanel;
	private JPanel mainNorthPanel, westPane_Pending, eastPane_Meetings, westPaneTop, westPaneBottom, eastPaneTop, eastPanebottom;
	private JPanel mainEastPanel;
	private JLabel pendingLbl, meetingLbl;
	private JScrollPane scrollPane;
	private JList<String> listPendings;
	private Vector<String> listData;
	private JLabel searchLable, noOfAttendees, meetingPurpose, bookedBy;
	private JTextField searchText;
	private JPanel centerPanel;
	private JButton schedulingButton;
	private JTable jTableMeetings;
	private JScrollPane sp;
	
	private static final Font font = new Font("Bookman Old Style", Font.ITALIC, 14);
	private static final Font otherFont = new Font("Bookman Old Style", Font.PLAIN, 11);
	private static final Font f = new Font("Bookman Old Style", Font.BOLD, 14);
	public static MainMenu main = new MainMenu();
	private JButton searchBtn = null , searchAgainBtn = null ;
	private JLabel infoLabel = null ;
	private JComboBox roomBox = null ;
	private JCalendar calendar;
	private JLabel infoLbl;
	private JTextArea bookedByArea;
	private JTextArea noOfAttendeesArea;
	private JTextArea purposeArea;
	private JScrollPane bookedByScroller;
	private JScrollPane attendeesScroller;
	private JScrollPane purposeScroller;
	public int count = 1;
	public MainMenu(){
		createMainPanel();
		registerListeners();
	}
	
	private void createAllPanels(){
		mainNorthPanel = new JPanel(new BorderLayout(1,10));
		mainNorthPanel.setBackground(Color.BLACK);
		westPane_Pending = new JPanel(new BorderLayout(1, 1));
		eastPane_Meetings = new JPanel(new BorderLayout(1, 1));
		westPaneTop = new JPanel(new FlowLayout(FlowLayout.LEFT));
		westPaneBottom  = new JPanel(new BorderLayout());
		eastPaneTop  = new JPanel(new FlowLayout(FlowLayout.LEFT));
		eastPanebottom  = new JPanel();
		
		pendingLbl = new JLabel("Pending Bookings: ");
		pendingLbl.setFont(font);
		westPaneTop.add(pendingLbl);
		meetingLbl = new JLabel("Scheduled Meetings: ");
		meetingLbl.setFont(font);
		eastPaneTop.add(meetingLbl);
		
		listData = new Vector<String>();
		
		listPendings = new JList<String>();
		listPendings.setFixedCellWidth(200);
		listPendings.setFont(otherFont);
		addListData();
		scrollPane = new JScrollPane(listPendings);
		roomBox = new JComboBox();
		roomBox.setBounds(118, 36, 111, 20);
		roomBox.addItem("Zambezi");
		roomBox.addItem("Amazon");
		roomBox.addItem("Nile");
		roomBox.addItem("Thames");
		roomBox.addItem("Missisippi");
		roomBox.addItem("Seine");
		roomBox.addItem("Ottawa");
		roomBox.addItem("Ebro");
		roomBox.addItem("Ganges");
		roomBox.addItem("Congo");
		roomBox.addItem("Mosman");
		roomBox.addItem("Rhine");
		//CREATE THE TABLE OF SCHEDULED MEETINGS
		String [] columnNames = new String[]{"Scheduled", "Details"};
		String [][] rows = new String[][] {{"1", "test1"}, {"2", "test2"}};
		sp = new JScrollPane();
		sp.setBounds(-99, 5, 680, 127);
		eastPanebottom.setBackground(Color.LIGHT_GRAY);
		//FINISH CREATION OF TABLE OF SCHEDULED MEEETINGS
		
		//CREATE PANEL FORM TO SEARCH FOR A ROOM
		mainEastPanel = new JPanel();
		mainEastPanel.setMaximumSize(new Dimension(300, 500));
		mainEastPanel.setPreferredSize(new Dimension(325, 500));
		mainEastPanel.setBackground(Color.GRAY);
		
		infoLabel = new JLabel("Query a Room ");
		infoLabel.setBounds(3, 5, 271, 26);
		infoLabel.setFont(new Font("Arial" , Font.BOLD , 22));
		searchLable = new JLabel("Select a room : ");
		searchLable.setBounds(3, 37, 112, 18);
		searchLable.setFont(f);
		
		searchBtn = new JButton("Search");
		searchBtn.setBounds(118, 66, 90, 23);
		searchBtn.addActionListener(e-> {
			bookedBy.setVisible(true);
			meetingPurpose.setVisible(true);
			noOfAttendees.setVisible(true);
			//JTF's
			bookedByScroller.setVisible(true);
			attendeesScroller.setVisible(true);
			purposeScroller.setVisible(true);
			searchAgainBtn.setVisible(true);
			searchBtn.setVisible(false);
			Controller.getInstance().searchDetails((String) roomBox.getSelectedItem());
			
		});
		searchAgainBtn = new JButton("Search for another room");
		searchAgainBtn.setBounds(3, 364, 193, 23);
		searchAgainBtn.addActionListener(e-> {
			//searchText.setText("");
			//lables
			bookedBy.setVisible(false);
			meetingPurpose.setVisible(false);
			noOfAttendees.setVisible(false);
			//JTF's
			bookedByScroller.setVisible(false);
			attendeesScroller.setVisible(false);
			purposeScroller.setVisible(false);
			searchAgainBtn.setVisible(false);
			searchBtn.setVisible(true);
			
		});
		searchAgainBtn.setVisible(false);
		
		bookedBy = new JLabel("Booked By: ");
		bookedBy.setBounds(3, 88, 128, 18);
		bookedBy.setFont(f);
		meetingPurpose = new JLabel("Purpose: ");
		meetingPurpose.setBounds(3, 266, 68, 18);
		meetingPurpose.setFont(f);
		noOfAttendees = new JLabel("Number of attendees: ");
		noOfAttendees.setBounds(3, 187, 156, 18);
		noOfAttendees.setFont(f);
		searchLable.setLabelFor(roomBox);
		mainEastPanel.setLayout(null);
		mainEastPanel.add(infoLabel);
		mainEastPanel.add(searchLable);
		mainEastPanel.add(roomBox);
		mainEastPanel.add(bookedBy);
		mainEastPanel.add(noOfAttendees);
		mainEastPanel.add(meetingPurpose);
		mainEastPanel.add(searchBtn);
		mainEastPanel.add(searchAgainBtn);
		
		centerPanel = new JPanel();
		
		centerPanel.setBackground(Color.GRAY);
		schedulingButton = new JButton("Schedule New Meeting");
		schedulingButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		schedulingButton.setBounds(59, 457, 210, 23);
		mainEastPanel.add(schedulingButton);
		//centerPanel.add(schedulingButton);
		mainPanel.add(centerPanel, BorderLayout.CENTER);
		centerPanel.setLayout(null);
		
		calendar = new JCalendar();
		calendar.setTodayButtonText("Go to Today");
		calendar.getDayChooser().setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		calendar.getDayChooser().setWeekdayForeground(Color.BLACK);
		calendar.setDecorationBackgroundColor(new Color(128, 128, 128));
		calendar.setTodayButtonVisible(true);
		calendar.getDayChooser().getDayPanel().setBackground(SystemColor.activeCaption);
		calendar.getDayChooser().setBackground(Color.LIGHT_GRAY);
		calendar.getMonthChooser().setBackground(Color.LIGHT_GRAY);
		
		
		calendar.setBounds(0, 0, 475, 517);
		centerPanel.add(calendar);
		mainPanel.add(mainEastPanel, BorderLayout.EAST);
		
		infoLbl = new JLabel("");
		infoLbl.setBounds(226, 15, 46, 14);
		mainEastPanel.add(infoLbl);
		
		bookedByScroller = new JScrollPane();
		bookedByScroller.setBounds(3, 108, 210, 68);
		mainEastPanel.add(bookedByScroller);
		
		bookedByArea = new JTextArea();
		bookedByScroller.setViewportView(bookedByArea);
		bookedByArea.setEditable(false);
		
		attendeesScroller = new JScrollPane();
		attendeesScroller.setBounds(3, 206, 204, 54);
		mainEastPanel.add(attendeesScroller);
		
		noOfAttendeesArea = new JTextArea();
		attendeesScroller.setViewportView(noOfAttendeesArea);
		noOfAttendeesArea.setEditable(false);
		
		purposeScroller = new JScrollPane();
		purposeScroller.setBounds(3, 284, 204, 69);
		mainEastPanel.add(purposeScroller);
		
		purposeArea = new JTextArea();
		purposeScroller.setViewportView(purposeArea);
		purposeArea.setEditable(false);
		//FINISH CREATION OF PANEL FORM TO SEARCH FOR A ROOM
		
		//CREATE BOTTOM PANEL FOR IDK???
		//FINISH BOTTOM PANEL FOR IDK
		
		westPaneBottom.add(scrollPane, BorderLayout.CENTER);
		eastPanebottom.setLayout(null);
		eastPanebottom.add(sp);
		westPane_Pending.add(westPaneTop, BorderLayout.NORTH);
		westPane_Pending.add(westPaneBottom, BorderLayout.SOUTH);
		mainNorthPanel.add(westPane_Pending, BorderLayout.WEST);
		eastPane_Meetings.add(eastPaneTop, BorderLayout.NORTH);
		eastPane_Meetings.add(eastPanebottom, BorderLayout.SOUTH);
		mainNorthPanel.add(eastPane_Meetings, BorderLayout.CENTER);
		jTableMeetings = new JTable(rows, columnNames);
		eastPane_Meetings.add(jTableMeetings, BorderLayout.CENTER);
		jTableMeetings.setEnabled(false);
		jTableMeetings.setPreferredScrollableViewportSize(new Dimension(678, 100));
		mainPanel.add(mainNorthPanel, BorderLayout.NORTH);
		bookedBy.setVisible(false);
		meetingPurpose.setVisible(false);
		noOfAttendees.setVisible(false);
		
		bookedByScroller.setVisible(false);
		attendeesScroller.setVisible(false);
		purposeScroller.setVisible(false);
		
	}
	
	/**
	 * @return the searchText
	 */
	public JComboBox<String> getSearchSelection() {
		return (JComboBox<String>) roomBox.getSelectedItem();
		
	}

	

	

	/**
	 * @param noOfAttendeesText the noOfAttendeesText to set
	 */
	public void setNoOfAttendeesText(String noOfAttendeesText) {
		this.noOfAttendeesArea.setText(noOfAttendeesText);
	}

	

	/**
	 * @param bookedByText the bookedByText to set
	 */
	public void setBookedByText(String bookedByText) {
		this.bookedByArea.setText(bookedByText);
		
	}

	

	/**
	 * @param purposeText the purposeText to set
	 */
	public void setPurposeText(String purposeText) {
		this.purposeArea.setText(purposeText);
	}

	private void registerListeners() {
		schedulingButton.addActionListener(e -> {
			MainFrame.addToFrame(Questionnaire.ques.returnQues());
		});
		listPendings.addListSelectionListener(main);
		
	}

	private void createMainPanel() {
		mainPanel = new JPanel(new BorderLayout());
		createAllPanels();
		mainPanel.setVisible(true);
		mainPanel.setBackground(Color.RED);
	}

	public JPanel getInstance() {
		if(mainPanel == null){
			return null;
		}
		return mainPanel;
	}

	
	public void addListData(){
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				listPendings.removeListSelectionListener(main);
				listData.removeAllElements();	
				listData.addAll(Controller.getInstance().returnBookings());
				listPendings.setListData(listData);
				listPendings.addListSelectionListener(main);
				listPendings.repaint();
				westPaneBottom.repaint();
			}
		});
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(e.getValueIsAdjusting()){
			return;
		}
		int i = JOptionPane.showConfirmDialog(mainPanel, "Confirm Booking ?", "Confirmation", JOptionPane.YES_NO_OPTION);
		if(i == 0){
			Controller.getInstance().confirmBooking(listPendings.getSelectedValue());
		} else {
			if(i == 1){
				Controller.getInstance().cancelBooking(listPendings.getSelectedValue(), null);
			}
		}
		System.out.println(i);
	}

	public void setCenterPanel(JPanel comp) {
		centerPanel.removeAll();
		centerPanel.repaint();
		centerPanel.validate();
		centerPanel.add(comp,BorderLayout.CENTER);
		centerPanel.repaint();
		centerPanel.validate();
	}
	}
	
	


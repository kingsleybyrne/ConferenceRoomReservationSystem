package za.co.vzap.client;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.Icon;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class ProgressBar extends JFrame {

	private JPanel contentPane;
	protected JLabel lblLoading;
	protected JProgressBar progressBar;
	private JLabel image;
	private JLabel logo ;
	private JLabel logoLbl;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProgressBar frame = new ProgressBar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProgressBar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//contentPane.is
		//panel.add(progressBar);
		
		image = new JLabel("");
		image.setIcon(new ImageIcon("C:\\Users\\Graham\\Desktop\\conferenceRoom.jpeg"));
		image.setBounds(0, 0, 633, 360);
		
		logo = new JLabel();
		//logo.setIcon("resources/Screenshot(3)small.png"));
		
		progressBar = new JProgressBar();
		
		progressBar.setForeground(SystemColor.textHighlight);
		progressBar.setBounds(0, 333, 633, 14);
		image.add(progressBar);
		
		
		
		lblLoading = new JLabel("Loading...");
		//contentPane.add(lblLoading);
		
		lblLoading.setForeground(SystemColor.text);
		lblLoading.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblLoading.setBounds(112, 304, 132, 20);
		image.add(lblLoading);
		
		
		
		
		
		logoLbl = new JLabel();
		logoLbl.setHorizontalAlignment(SwingConstants.CENTER);
		//contentPane.add(logoLbl);
		
		logoLbl.setIcon(new ImageIcon("E:\\logo\\Screenshot (3)small.png"));
		logoLbl.setBounds(180, 28, 405, 105);
		logoLbl.setPreferredSize(new Dimension(300, 300));
		image.add(logoLbl);
		contentPane.add(image);
		
		
		
	}
}

package za.co.vzap.client.fxml;

import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class AlertBox {
	
	static int answer = 1;
	static int ansError = 1;
	
	public static int display(String title, String message, String b1, String b2){
		Stage window = new Stage();
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent t) {
		    	answer = -1;
		        window.close();
		        
		    }
		});
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(450);
		window.setMinHeight(200);
		Label label = new Label(message);
		Button ok = new Button(b1);
		ok.setOnAction(e -> {
			answer = 0;
			window.close();
		});
		Button cancel = new Button(b2);
		cancel.setOnAction(e -> {
			answer = 1;
			window.close();
		});
		VBox layout = new VBox(10);
		layout.getChildren().addAll(label,ok,cancel);
		layout.setAlignment(Pos.CENTER);
		Scene s = new Scene(layout);
		window.setScene(s);
		window.showAndWait();
		
		return answer;
	}

	public static int showErrorDialogue(String msg, String btn) {
		Stage window = new Stage();
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent t) {
		    	ansError = -1;
		        window.close();
		    }
		});
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("ERROR");
		window.setMinWidth(450);
		window.setMinHeight(200);
		Label label = new Label(msg);
		Button ok = new Button(btn);
		ok.setOnAction(e -> {
			ansError = 0;
			window.close();
		});
		VBox layout = new VBox(10);
		layout.getChildren().addAll(label,ok);
		layout.setAlignment(Pos.CENTER);
		Scene s = new Scene(layout);
		window.setScene(s);
		window.showAndWait();
		
		return ansError;
	}
	public static int display(String title, String message, String b1){
		Stage window = new Stage();
		window.setOnCloseRequest(new EventHandler<WindowEvent>() {
		    @Override
		    public void handle(WindowEvent t) {
		    	answer = -1;
		        window.close();
		    }
		});
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(450);
		window.setMinHeight(200);
		Label label = new Label(message);
		Button ok = new Button(b1);
		ok.setOnAction(e -> {
			answer = 0;
			window.close();
		});
		
		VBox layout = new VBox(10);
		layout.getChildren().addAll(label,ok);
		layout.setAlignment(Pos.CENTER);
		Scene s = new Scene(layout);
		window.setScene(s);
		window.showAndWait();
		
		return answer;
	}
	
	
}

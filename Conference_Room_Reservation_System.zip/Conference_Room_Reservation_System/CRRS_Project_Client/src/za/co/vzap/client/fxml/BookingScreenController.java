package za.co.vzap.client.fxml;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ResourceBundle;

import com.jfoenix.concurrency.JFXUtilities;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;

import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import za.co.vzap.client.fx.AddEquip;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.RoomDTO;
import za.co.vzap.dto.WaitingListDTO;

public class BookingScreenController implements Initializable{
	@FXML
	private MenuItem menuHome;
	@FXML
	private MenuItem menuClose;
	@FXML
	private MenuItem menuQuestionnaire;
	@FXML
	private MenuItem menuSearch;
	@FXML
	private MenuItem menuReports;
	@FXML
	private MenuItem menuHelp;
	@FXML
	private ImageView image1;
	@FXML
	private Label startTime, endTime;
	@FXML
	private TableView<AddEquip> equipmentTable;
	@FXML
	private TableView<AddRoom> roomTable;
	@FXML
	private TextArea description;
	@FXML
	private TextArea roomDetails;
	@FXML
	private Label nameLbl1, titleLbl1, cellNoLbl1, deptLbl1, emailLbl1;
	@FXML
	private JFXButton editBTN;
	@FXML
	private JFXButton bookBTN;
	@FXML
	private JFXButton cancelBTN;
	private RoomDTO roomToBook;
	private String statusOfRoom;
	private String theirDate;
	
	public static String timeS = "";
	public static String timeE = "";
	private static String startingTime;
	private static String endingTime;
	private static LocalDate startingDate;
	private static LocalDate endingDate;
	private static int noOfAttendees;
	private static ArrayList<String> equipmentList;
	private static ArrayList<String> quantityList;
	private static ObservableList<AddEquip> equipmentListForTable;
	
	public void gotoQuestionnaireScreen(){
		MainStage.getStage().setScene(HomeScreenController.getQuestionnaireScreen());
	}
	public void finalizeBooking() throws IOException{
		
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
			startingTime = startingTime +":00";
			endingTime = endingTime +":00";
			String timeStart = df.format(df.parse(theirDate)) + " " + formatter.format(formatter.parse(startingTime));
			String timeEnd = df.format(df.parse(theirDate)) + " " + formatter.format(formatter.parse(endingTime));
			ArrayList<Integer> intList = new ArrayList<>();
			for(String s : quantityList){
				intList.add(Integer.parseInt(s));
			}
			String status = "";
			if(roomToBook!=null && description.getText()!=null && statusOfRoom!=null){
				if(statusOfRoom.equalsIgnoreCase("booked")){
					status = "Waiting";
				} else {
					status = "Pending";
				}
				
				BookingDTO clientBooking = new BookingDTO(ClientFX.getInstance().getClient().getClientName(), ClientFX.getInstance().getClient().getClientSurname(),
						timeStart,
						timeEnd, status, roomToBook.getRoomName(), description.getText(), noOfAttendees);
				int b = AlertBox.display("Confirm", "Confirm Booking for " + roomToBook.getRoomName() + " now?", "Yes","Later");
				if(b == 0){
					if(status.equalsIgnoreCase("pending")){
						clientBooking.setBooked("Booked");
						ClientFX.getInstance().book(clientBooking, equipmentList, intList);
					} else {
						ClientFX.getInstance().book(clientBooking, equipmentList, intList);
					}
					ClientFX.getInstance().returnBookings().add(clientBooking);
					MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
				} else {
					if(b == 1){
						if(status.equalsIgnoreCase("pending")){
							ClientFX.getInstance().book(clientBooking, equipmentList, intList);
						} else {
							ClientFX.getInstance().book(clientBooking, equipmentList, intList);
						}
						ClientFX.getInstance().returnBookings().add(clientBooking);
						MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
					}
					if(b == -1){
						clearAllFields();
						MainStage.getStage().setScene(HomeScreenController.getQuestionnaireScreen());
					}
				}
			}
			
		} catch (NumberFormatException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException n){
			AlertBox.showErrorDialogue("Please select a Room", "Ok");
		}
	}
	public void clearAllFields() throws IOException{
		description.setText("");
		roomDetails.setText("");
		
//		Parent phomeScreen = FXMLLoader.load(getClass().getResource("QuestionnaireScreen.fxml"));
//		Scene homeScreen = new Scene(phomeScreen);
//		MainStage.getStage().setScene(homeScreen);
	}
	private List<Date> getDaysBetween(Date startingDate2, Date endingDate2) throws ParseException{						
		List<Date> dates = new ArrayList<Date>();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(startingDate2);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		while(calendar.getTime().before(endingDate2)){
			Date result = df.parse(df.format(calendar.getTime()));
			dates.add(result);
			calendar.add(Calendar.DATE, 1);
		}
		return dates;
	}
	public void setRoomTable(){
		try {
			ClientFX.getInstance().searchRooms(noOfAttendees);
			
			ArrayList<RoomDTO> rooms = ClientFX.getInstance().getRoomsAvailable();
			Date clientStartDate = Date.from(startingDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			Date clientEndDate = Date.from(endingDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat formatter = new SimpleDateFormat("HH:mm");
			ArrayList<Date> range = (ArrayList<Date>) getDaysBetween(clientStartDate, clientEndDate);
			
			Date selectedStartTime = (Date) formatter.parse(startingTime);
			Date selectedEndTime = (Date) formatter.parse(endingTime);
//			Date bookingStartTime = (Date) formatter.parse(booking.get(j).getStartDate().substring(11, 16));
//			Date bookingEndTime = (Date) formatter.parse(booking.get(j).getEndDate().substring(11, 16));
			ArrayList<AddRoom> addRoom = new ArrayList<>();
			for(int i = 0; i < range.size(); i++){
				for(RoomDTO room : rooms){
					if(hasBookings(room, range.get(i))){
						roomTable.getItems().add(new AddRoom(room.getRoomName(), df.format(range.get(i)), "Booked"));
					} else {
						roomTable.getItems().add(new AddRoom(room.getRoomName(), df.format(range.get(i)), "Available"));
					}
				}
			}
			
		} catch (ClassNotFoundException | IOException | ParseException e) {
			e.printStackTrace();
		}
	}
	
	private boolean hasBookings(RoomDTO room, Date rangeDate) throws ParseException {
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat formatter = new SimpleDateFormat("HH:mm");
		
		String dateRange = df.format(rangeDate);
		
		Date clientStartDate = Date.from(startingDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		Date clientEndDate = Date.from(endingDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());

		Date selectedStartTime = (Date) formatter.parse(startingTime);
		Date selectedEndTime = (Date) formatter.parse(endingTime);
		
		for(BookingDTO book : ClientFX.getInstance().getBookingsOnRooms()){
			Date bookingStartTime = (Date) formatter.parse(book.getStartDate().substring(11, 16));			
			Date bookingEndTime = (Date) formatter.parse(book.getEndDate().substring(11, 16));
			
			String bookingStartDate = df.format(df.parse(book.getStartDate().substring(0, 10)));
			
			if(room.getRoomName().equals(book.getRoomName()) && dateRange.equals(bookingStartDate) ){
				if(selectedStartTime.equals(bookingStartTime)||(selectedStartTime.after(bookingStartTime)||selectedStartTime.before(bookingEndTime))||(selectedEndTime.after(bookingStartTime)||selectedEndTime.before(bookingEndTime))){
					return true;
				}
			} 
		}
		return false;
	}
	public void validate(){
		int b = AlertBox.display("Confirm", "You have selected " + roomTable.getSelectionModel().getSelectedItem().getName(), "Ok", "No");

		try {
			if(b == 0){
				for(RoomDTO r : ClientFX.getInstance().getRoomsAvailable()){
					if(r.getRoomName().equals(roomTable.getSelectionModel().getSelectedItem().getName())){
						theirDate = roomTable.getSelectionModel().getSelectedItem().getDate();
						roomToBook = r;
						if(roomTable.getSelectionModel().getSelectedItem().getStatus().equalsIgnoreCase("booked")){
							statusOfRoom = "Booked";
							roomDetails.setText(r.getRoomName() + " is booked, You will be added to wait list\n" +noOfPPl(r,theirDate));
						} else{
							statusOfRoom = "Available";
							roomDetails.setText(r.toString());
						}

					}
				}
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}

	private String noOfPPl(RoomDTO r, String theirDate2) throws ClassNotFoundException, IOException {
		System.out.println(r.getRoomName() + "in noOfPPL ");
		ArrayList<WaitingListDTO> waitlist = new ArrayList<>();
		for(WaitingListDTO w : ClientFX.getInstance().getAllOnWaitList()){
			if(w.isWaitingStatus() && w.getClientName().equals(ClientFX.getInstance().getClient().getClientName())){
				if(r.getRoomName().equals(w.getRoomName()) && theirDate2.equals(w.getDateStart().substring(0, 10))){
					waitlist.add(w);
					System.out.println(w.getRoomName() + " " + w.getClientName() + " " + w.getDateStart());
				}
			}
		}
		return "There are currently [" + waitlist.size() + "] employees on the waiting list for this room";
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		createTable();
		createRoomTable();
		setRoomTable();
		setPersonDetails(); 
		startTime.setText(startingTime);
		endTime.setText(endingTime);
		roomDetails.setEditable(false);

	}
	//to be used in another class
	public static void setTimes(String selectedItem, String selectedItem2) {
		startingTime = selectedItem;
		endingTime = selectedItem2;
	}
	public static void setDates(LocalDate value, LocalDate value2) {
		startingDate = value;
		endingDate = value2;
	}
	public static void setAtt(String selectedItem) {
		if(selectedItem!=null){
			noOfAttendees = Integer.parseInt(selectedItem);
		}
		
	}
	public static void setList(ObservableList<AddEquip> equip) {
		equipmentListForTable = equip;
		equipmentList=new ArrayList<>();
		quantityList=new ArrayList<>();
		for(AddEquip e : equip){
			equipmentList.add(e.getS());
			quantityList.add(e.getT());
		}
	}
	//end comment
	public void setPersonDetails(){
		JFXUtilities.runInFX(new Runnable() {

			@Override
			public void run() {
				nameLbl1.setText(ClientFX.getInstance().getClient().getClientName());
				titleLbl1.setText(ClientFX.getInstance().getClient().getClientTitle());
				cellNoLbl1.setText(ClientFX.getInstance().getClient().getClientPhoneNumber());
				deptLbl1.setText(ClientFX.getInstance().getClient().getDepartment());
				emailLbl1.setText(ClientFX.getInstance().getClient().getClientEmail());
			}
		});
	}
	@SuppressWarnings("unchecked")
	private void createTable() {
		TableColumn<AddEquip, String> nameColumn = new TableColumn<>("Equipment");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("s"));

		TableColumn<AddEquip, String> nextColumn = new TableColumn<>("Quantity");
		nextColumn.setMinWidth(200);
		nextColumn.setCellValueFactory(new PropertyValueFactory<>("t"));
		equipmentTable.getColumns().addAll(nameColumn, nextColumn);
		equipmentTable.setItems(equipmentListForTable);
	}
	@SuppressWarnings("unchecked")
	private void createRoomTable() {
		TableColumn<AddRoom, String> nameColumn = new TableColumn<>("Room Name");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

		TableColumn<AddRoom, String> dateColumn = new TableColumn<>("Date");
		dateColumn.setMinWidth(200);
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));

		TableColumn<AddRoom, String> statusColumn = new TableColumn<>("Status");
		statusColumn.setMinWidth(200);
		statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
		roomTable.getColumns().addAll(nameColumn, dateColumn, statusColumn);
	}
	public void gotoHomeScreen(){
		MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
	}
	public void closeTheProgram(){
		MainStage.getStage().close();
		System.exit(0);
	}
	public void gotoSearchScreen() throws IOException{
		
		MainStage.getStage().setScene(HomeScreenController.getSearchScreen());
	}
	public void gotoReports() throws IOException{
		MainStage.getStage().setScene(HomeScreenController.getReportsScreen());
	}
	public void displayHelp(){
		
	}
}

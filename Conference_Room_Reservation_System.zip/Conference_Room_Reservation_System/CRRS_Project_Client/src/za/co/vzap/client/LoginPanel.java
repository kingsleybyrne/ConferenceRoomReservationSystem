package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.BevelBorder;

import za.co.vzap.client.Controller;


import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.ImageIcon;

public class LoginPanel extends JPanel implements ActionListener  {
	public static LoginPanel login = new LoginPanel();
	private JPanel loginPanel;
	private JPanel panel;
	private JLabel label;
	private JLabel label_1;
	private JPasswordField passwordField;
	private JCheckBox checkBox;
	private JTextField emailJTF;
	private JButton loginBtn;
	private JButton cancelBtn;
	private JLabel label_2;
	private JLabel imageLbl;
	/**
	 * Create the panel.
	 */
	public LoginPanel() {
		
		loginPanel = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(loginPanel, GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(loginPanel, GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
		);
		loginPanel.setLayout(null);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBounds(130, 133, 433, 303);
		
		loginPanel.add(panel);
		
		label = new JLabel("Email");
		label.setFont(new Font("SansSerif", Font.PLAIN, 14));
		
		label_1 = new JLabel("Password");
		label_1.setFont(new Font("SansSerif", Font.PLAIN, 14));
		
		passwordField = new JPasswordField();
		passwordField.setToolTipText("Field for your password");
		
		checkBox = new JCheckBox("Show Password");
		
		emailJTF = new JTextField();
		emailJTF.setToolTipText("Field for your email address");
		emailJTF.setColumns(10);
		
		loginBtn = new JButton("Login");
		loginBtn.setForeground(Color.BLACK);
		loginBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
		loginBtn.addActionListener(this);
		
		cancelBtn = new JButton("Cancel");
		cancelBtn.setForeground(Color.BLACK);
		cancelBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
		cancelBtn.addActionListener(this);
		
		label_2 = new JLabel("Welcome");
		label_2.setFont(new Font("Palatino Linotype", Font.PLAIN, 32));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGap(0, 433, Short.MAX_VALUE)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(89)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
								.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
								.addComponent(checkBox)
								.addComponent(emailJTF, GroupLayout.PREFERRED_SIZE, 231, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(111)
							.addComponent(loginBtn)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(cancelBtn, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(138)
							.addComponent(label_2)))
					.addContainerGap(102, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGap(0, 303, Short.MAX_VALUE)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(20)
					.addComponent(label_2)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(label, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(emailJTF, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(checkBox)
					.addGap(11)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(loginBtn)
						.addComponent(cancelBtn))
					.addContainerGap(44, Short.MAX_VALUE))
		);
		gl_panel.setAutoCreateGaps(true);
		gl_panel.setAutoCreateContainerGaps(true);
		panel.setLayout(gl_panel);
		
		imageLbl = new JLabel("");
		imageLbl.setIcon(new ImageIcon("C:\\Users\\Graham\\Desktop\\loginBackground.jpg"));
		imageLbl.setBounds(0, 0, 800, 700);
		loginPanel.add(imageLbl);
		setLayout(groupLayout);

	}
	public JPanel getInstance()
	{
		return login ;
	}

	public void clearFields() {
		emailJTF.setText("");
		passwordField.setText("");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == loginBtn)
		{
			String email = emailJTF.getText();
			char[] password = passwordField.getPassword();
			Controller.getInstance().validate(email, password);
		}
		if(source == cancelBtn)
		{
			emailJTF.setText("");
			passwordField.setText("");
		}
		
	}
}

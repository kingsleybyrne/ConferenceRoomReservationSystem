package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReportPage extends JPanel {
	private JPanel reportPanel;
	private JPanel nPanel;
	private JLabel lblReports;
	private JPanel cancellationsPanel;
	private JLabel lblFrom;
	private JComboBox monthBox;
	private JComboBox yearBox;
	private JLabel lblTo;
	private JComboBox monthEndBox;
	private JComboBox yearEndBox;
	private JButton btnViewNumberOf;
	private JButton venueUsageBtn;
	private JButton equipmentUsageBtn;
	private JButton waitListBtn;
	private JPanel btnPabnel;
	public static ReportPage rp = new ReportPage();
	/**
	 * Create the panel.
	 */
	public ReportPage() {
		
		reportPanel = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(reportPanel, GroupLayout.PREFERRED_SIZE, 607, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(reportPanel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
		);
		
		nPanel = new JPanel();
		nPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		cancellationsPanel = new JPanel();
		cancellationsPanel.setBorder(new CompoundBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Time Period", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))), null));
		
		btnPabnel = new JPanel();
		btnPabnel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Select an option below :", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))));
		GroupLayout gl_reportPanel = new GroupLayout(reportPanel);
		gl_reportPanel.setHorizontalGroup(
			gl_reportPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_reportPanel.createSequentialGroup()
					.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(484, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_reportPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(cancellationsPanel, GroupLayout.PREFERRED_SIZE, 583, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(89, Short.MAX_VALUE))
				.addGroup(gl_reportPanel.createSequentialGroup()
					.addContainerGap(248, Short.MAX_VALUE)
					.addComponent(btnPabnel, GroupLayout.PREFERRED_SIZE, 292, GroupLayout.PREFERRED_SIZE)
					.addGap(172))
		);
		gl_reportPanel.setVerticalGroup(
			gl_reportPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_reportPanel.createSequentialGroup()
					.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(cancellationsPanel, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
					.addGap(28)
					.addComponent(btnPabnel, GroupLayout.PREFERRED_SIZE, 157, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(64, Short.MAX_VALUE))
		);
		
		btnViewNumberOf = new JButton("View Number of Cancellations");
		btnViewNumberOf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayCancellationsReport();
			}
		});
		
		venueUsageBtn = new JButton("View Venue Occupation");
		venueUsageBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				Controller.getInstance().displayRoomReport();
				
			}
		});
		
		waitListBtn = new JButton("View Wait List");
		waitListBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayWaitListReport();
			}
		});
		
		equipmentUsageBtn = new JButton("View Equipment  Usage");
		equipmentUsageBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayEquipmentReport();
			}
		});
		GroupLayout gl_btnPabnel = new GroupLayout(btnPabnel);
		gl_btnPabnel.setHorizontalGroup(
			gl_btnPabnel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_btnPabnel.createSequentialGroup()
					.addGroup(gl_btnPabnel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_btnPabnel.createSequentialGroup()
							.addGap(84)
							.addComponent(waitListBtn))
						.addGroup(gl_btnPabnel.createSequentialGroup()
							.addGap(50)
							.addGroup(gl_btnPabnel.createParallelGroup(Alignment.LEADING)
								.addComponent(btnViewNumberOf)
								.addGroup(gl_btnPabnel.createSequentialGroup()
									.addGap(10)
									.addGroup(gl_btnPabnel.createParallelGroup(Alignment.TRAILING)
										.addComponent(equipmentUsageBtn)
										.addComponent(venueUsageBtn))))))
					.addContainerGap(53, Short.MAX_VALUE))
		);
		gl_btnPabnel.setVerticalGroup(
			gl_btnPabnel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_btnPabnel.createSequentialGroup()
					.addComponent(btnViewNumberOf)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(venueUsageBtn)
					.addGap(11)
					.addComponent(equipmentUsageBtn)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(waitListBtn)
					.addContainerGap(25, Short.MAX_VALUE))
		);
		btnPabnel.setLayout(gl_btnPabnel);
		
		lblFrom = new JLabel("From :");
		
		monthBox = new JComboBox();
		monthBox.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May ", "June", "July", "August", "September", "October", "November", "December"}));
		
		yearBox = new JComboBox();
		yearBox.setModel(new DefaultComboBoxModel(new String[] {"2018", "2019", "2020"}));
		
		lblTo = new JLabel("To :");
		
		monthEndBox = new JComboBox();
		monthEndBox.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May ", "June", "July", "August", "September", "October", "November", "December"}));
		
		yearEndBox = new JComboBox();
		yearEndBox.setModel(new DefaultComboBoxModel(new String[] {"2018", "2019", "2020"}));
		GroupLayout gl_cancellationsPanel = new GroupLayout(cancellationsPanel);
		gl_cancellationsPanel.setHorizontalGroup(
			gl_cancellationsPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_cancellationsPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblFrom)
					.addGap(18)
					.addComponent(monthBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(yearBox, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
					.addGap(32)
					.addComponent(lblTo)
					.addGap(18)
					.addComponent(monthEndBox, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(yearEndBox, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(121, Short.MAX_VALUE))
		);
		gl_cancellationsPanel.setVerticalGroup(
			gl_cancellationsPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_cancellationsPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_cancellationsPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFrom)
						.addComponent(monthBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(yearBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTo)
						.addComponent(monthEndBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(yearEndBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(16, Short.MAX_VALUE))
		);
		cancellationsPanel.setLayout(gl_cancellationsPanel);
		
		lblReports = new JLabel("Reports");
		lblReports.setFont(new Font("Tahoma", Font.BOLD, 15));
		GroupLayout gl_nPanel = new GroupLayout(nPanel);
		gl_nPanel.setHorizontalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_nPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblReports)
					.addContainerGap(54, Short.MAX_VALUE))
		);
		gl_nPanel.setVerticalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_nPanel.createSequentialGroup()
					.addContainerGap(22, Short.MAX_VALUE)
					.addComponent(lblReports)
					.addContainerGap())
		);
		nPanel.setLayout(gl_nPanel);
		reportPanel.setLayout(gl_reportPanel);
		setLayout(groupLayout);

	}
	public JPanel returnReportPage() {
		return rp;
	}
}

package za.co.vzap.client.main;
import za.co.vzap.dto.*;
import java.net.*;
import java.io.*;
import java.util.*;
public class ClientMain 
{
	private Socket socket = null;
	private ObjectInputStream ois = null;
	private ObjectOutputStream oos = null;
	private ClientDTO client = null; 
	
	private ArrayList<BookingDTO> clientBookings = null;
	private ArrayList<RoomDTO> roomUseStats = null;
	private ArrayList<RoomCancellationsDTO> roomCancelStats = null;		
	private ArrayList<RoomEquipmentDTO> equipmentStats = null;
	private ArrayList<RoomDTO> roomsAvailable = null;
	private ArrayList<BookingDTO> bookingsOnRooms = null;
	
	private ArrayList<ClientDTO> clientThatBooked;
	private ArrayList<BookingDTO> bookingDetails = null;
	
	public ClientMain()
	{
		try 
		{
			socket = new Socket("localhost", 20000);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			
		} 
		catch (UnknownHostException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void choice(int choice)
	{
		try 
		{
			oos.writeUTF(String.valueOf(choice));
			oos.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void searchForRoom(String roomName) throws IOException, ClassNotFoundException{
		choice(3);
		oos.writeObject(roomName);
		oos.flush();
		
		clientThatBooked = (ArrayList<ClientDTO>) ois.readObject();
		bookingDetails = (ArrayList<BookingDTO>) ois.readObject();	
	}
	
	public ArrayList<ClientDTO> getClientThatBooked(){
		return clientThatBooked;
	}

	/**
	 * @return the bookingDetails
	 */
	public ArrayList<BookingDTO> getBookingDetails() {
		return bookingDetails;
	}

	@SuppressWarnings("unchecked")
	public ClientDTO login(String email, String password)
	{
		UserDTO user = new UserDTO(email, password);
		try 
		{
			oos.writeObject(user);
			clientBookings = (ArrayList<BookingDTO>)(ois.readObject());
			client = (ClientDTO)(ois.readObject());
			return client;
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public void book(BookingDTO booking, ArrayList<String> roomEquipment, ArrayList<Integer> quantity) {
		choice(2);
		BookingDTO book = booking;
		try 
		{
			Thread.sleep(2000);
			oos.writeObject(book);
			int size = roomEquipment.size();
			oos.writeInt(size);
			while(size > 0)
			{
				RoomEquipmentDTO re = new RoomEquipmentDTO(book.getClientName(), book.getClientSurname(), book.getRoomName(), book.getStartDate(), book.getEndDate(), roomEquipment.get(size-1), quantity.get(size-1));
				System.out.println("Size = " + size + "\nEquipment = " + re.getRoomEquipment());
				Thread.sleep(1000);
				oos.writeObject(re);
				size--;
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{

			e.printStackTrace();
		}
	}
	public void cancelBooking(String clientName, String clientSurname, String roomName)
	{
		choice(6);
		try 
		{
			oos.writeUTF(clientName);
			oos.flush();
			oos.writeUTF(clientSurname);
			oos.flush();
			oos.writeUTF(roomName);
			oos.flush();
//			oos.writeUTF(dateOfbooking);
//			oos.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void searchRooms(int a) throws IOException, ClassNotFoundException {
		choice(5);
		oos.writeInt(a);
		oos.flush();
		roomsAvailable = null;
		bookingsOnRooms = null;
		roomsAvailable = (ArrayList<RoomDTO>) ois.readObject();
		bookingsOnRooms = (ArrayList<BookingDTO>) ois.readObject();
	}
	/**
	 * @return the roomsAvailable
	 */
	public ArrayList<RoomDTO> getRoomsAvailable() {
		return roomsAvailable;
	}

	/**
	 * @return the bookingsOnRooms
	 */
	public ArrayList<BookingDTO> getBookingsOnRooms() {
		return bookingsOnRooms;
	}

	public ArrayList<BookingDTO> returnBookings()
	{
		return clientBookings;
	}

	public void close()
	{

		try
		{
			socket.close();
			oos.close();
			ois.close();
			System.out.println("Connection to the server has been closed");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public ClientDTO getClient() {
		return client;
	}

	@SuppressWarnings("unchecked")
	public void getAllStats() throws ClassNotFoundException, IOException{
		choice(4);
		roomUseStats = (ArrayList<RoomDTO>) ois.readObject();
		roomCancelStats = (ArrayList<RoomCancellationsDTO>) ois.readObject();		
		equipmentStats = (ArrayList<RoomEquipmentDTO>) ois.readObject();

	}

	public ArrayList<RoomDTO> getRoomUseStats() throws ClassNotFoundException, IOException{
		return roomUseStats;
	}
	public ArrayList<RoomCancellationsDTO> getRoomCancleStats() throws ClassNotFoundException, IOException{
		return roomCancelStats;
	}
	public ArrayList<RoomEquipmentDTO> getRoomEquipmentStats() throws ClassNotFoundException, IOException{
		return equipmentStats;
	}

	public void confirmBooking(String clientName, String clientSurname, String value) {
		choice(7);
		try 
		{
			oos.writeUTF(clientName);
			oos.flush();
			oos.writeUTF(clientSurname);
			oos.flush();
			oos.writeUTF(value);
			oos.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void updateWaitingList(String roomName, String date){
		try {
			choice(8);
			oos.writeUTF(roomName);
			oos.flush();
			oos.writeUTF(date);
			oos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}

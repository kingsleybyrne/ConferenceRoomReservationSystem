package za.co.vzap.client.fxml;

import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PrintingClass {
	public static Stage stage;
	public static Node printNode;
  

  public static void print(Node node) {
	 stage = new Stage();
	 printNode = node;
    VBox root = new VBox(5);
    root.setPrefWidth(900.0);
    Label textLbl = new Label("Text:");
    TextArea text = new TextArea();
    text.setPrefRowCount(10);
    text.setPrefColumnCount(20);
    text.setWrapText(true);

    // Button to print the TextArea node
    Button printTextBtn = new Button("Confirm Print");
    printTextBtn.setOnAction(e -> printing(printNode));

    // Button to print the entire scene
    Button printSceneBtn = new Button("Print Scene");
    printSceneBtn.setOnAction(e -> printing(root));

    HBox buttonBox = new HBox(5, printTextBtn);

    root.getChildren().addAll(textLbl, printNode,  buttonBox);
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.setTitle("Printing Nodes");
    stage.showAndWait();
  }

  private static void printing(Node node) {
	  System.out.println("Creating a printer job...");

	  PrinterJob job = PrinterJob.createPrinterJob();
	  if (job != null) {
		  if( job.showPrintDialog(stage)){
			  System.out.println(job.jobStatusProperty().asString());

			  boolean printed = job.printPage(node);
			  if (printed) {
				
				  job.endJob();
				  AlertBox.display("Success", "Task Completed Successfully", "Ok");
				  stage.close();
			  } else {
				 AlertBox.showErrorDialogue("Task Failed", "Ok");
			  }
		  }

	  } else {
		  System.out.println("Could not create a printer job.");
	  }
  }
  public static void print(Node node, Node node2) {
	  stage = new Stage();
	  VBox toPrint = new VBox(node, node2);
	  toPrint.setStyle("-fx-background-color: #262626");
	  VBox root = new VBox(5);
	  root.setPrefWidth(900.0);
	  root.setStyle("-fx-background-color: #262626");
	  Label textLbl = new Label("To Print:");
	  Button printTextBtn = new Button("Confirm Print");
	  printTextBtn.setOnAction(e -> printing(toPrint));

	  HBox buttonBox = new HBox(5, printTextBtn);

	  root.getChildren().addAll(textLbl, toPrint,  buttonBox);
	  Scene scene = new Scene(root);
	  stage.setScene(scene);
	  stage.setTitle("Printing");
	  stage.showAndWait();
  }
}
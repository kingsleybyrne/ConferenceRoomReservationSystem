package za.co.vzap.client.fx;

import za.co.vzap.dto.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class ClientFX {


	private Socket socket = null;
	private ObjectInputStream ois = null;
	private ObjectOutputStream oos = null;
	private ClientDTO client = null; 

	private ArrayList<BookingDTO> clientBookings = null;
	private ArrayList<RoomDTO> roomUseStats = null;
	private ArrayList<RoomCancellationsDTO> roomCancelStats = null;		
	private ArrayList<RoomEquipmentDTO> equipmentStats = null;
	private ArrayList<RoomDTO> roomsAvailable = null;
	private ArrayList<BookingDTO> bookingsOnRooms = null;

	private ArrayList<ClientDTO> clientThatBooked;
	private ArrayList<BookingDTO> bookingDetails = null;
	private ArrayList<BookingDTO> allbookings;
	private ArrayList<RoomDTO> allRooms;
	private ArrayList<BookingDTO> bookingsForStats;
	/**
	 * @return the bookingsForStats
	 */
	public ArrayList<BookingDTO> getBookingsForStats() {
		return bookingsForStats;
	}
	/**
	 * @return the allbookings
	 */
	public ArrayList<BookingDTO> getAllbookings() {
		return allbookings;
	}
	/**
	 * @return the allRooms
	 */
	public ArrayList<RoomDTO> getAllRooms() {
		return allRooms;
	}

	private static ClientFX clientFX = new ClientFX();

	private ClientFX()
	{
		try 
		{
			socket = new Socket("localhost", 20000);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());

		} 
		catch (UnknownHostException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void allRooms(){
		choice(12);
		try {
			allRooms = (ArrayList<RoomDTO>) ois.readObject();
			allbookings = (ArrayList<BookingDTO>) ois.readObject();
			clientThatBooked = (ArrayList<ClientDTO>) ois.readObject();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void choice(int choice)
	{
		try 
		{
			oos.writeUTF(String.valueOf(choice));
			oos.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void searchForRoom(String roomName) throws IOException, ClassNotFoundException{
		choice(3);
		oos.writeObject(roomName);
		oos.flush();

		clientThatBooked = (ArrayList<ClientDTO>) ois.readObject();
		bookingDetails = (ArrayList<BookingDTO>) ois.readObject();	
	}

	public ArrayList<ClientDTO> getClientThatBooked(){
		return clientThatBooked;
	}

	/**
	 * @return the bookingDetails
	 */
	public ArrayList<BookingDTO> getBookingDetails() {
		return bookingDetails;
	}

	@SuppressWarnings("unchecked")
	public ClientDTO login(String email, String password)
	{
		UserDTO user = new UserDTO(email, password);
		try 
		{
			oos.writeObject(user);
			clientBookings = (ArrayList<BookingDTO>)(ois.readObject());
			client = (ClientDTO)(ois.readObject());
//			choice(13);
			return client;

		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	public void book(BookingDTO booking, ArrayList<String> roomEquipment, ArrayList<Integer> quantity) {
		choice(2);
		BookingDTO book = booking;
		try 
		{
			Thread.sleep(2000);
			oos.writeObject(book);
			int size = roomEquipment.size();
			oos.writeInt(size);
			while(size > 0)
			{
				RoomEquipmentDTO re = new RoomEquipmentDTO(book.getClientName(), book.getClientSurname(), book.getRoomName(), book.getStartDate(), book.getEndDate(), roomEquipment.get(size-1), quantity.get(size-1));
				System.out.println("Size = " + size + "\nEquipment = " + re.getRoomEquipment());
				Thread.sleep(1000);
				oos.writeObject(re);
				size--;
			}
			clientBookings.add(book);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (InterruptedException e) 
		{

			e.printStackTrace();
		}
	}
	public void cancelBooking(String clientName, String clientSurname, String roomName, String date)
	{
		choice(6);
		try 
		{
			oos.writeUTF(clientName);
			oos.flush();
			oos.writeUTF(clientSurname);
			oos.flush();
			oos.writeUTF(roomName);
			oos.flush();
			oos.writeUTF(date);
			oos.flush();
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void searchRooms(int a) throws IOException, ClassNotFoundException {
		choice(5);
		oos.writeInt(a);
		oos.flush();
		roomsAvailable = null;
		bookingsOnRooms = null;
		roomsAvailable = (ArrayList<RoomDTO>) ois.readObject();
		bookingsOnRooms = (ArrayList<BookingDTO>) ois.readObject();
	}
	/**
	 * @return the roomsAvailable
	 */
	public ArrayList<RoomDTO> getRoomsAvailable() {
		return roomsAvailable;
	}
	public ArrayList<RoomCancellationsDTO> getRoomCancelStats()
	{
		return roomCancelStats;
	}

	/**
	 * @return the bookingsOnRooms
	 */
	public ArrayList<BookingDTO> getBookingsOnRooms() {
		return bookingsOnRooms;
	}

	public ArrayList<BookingDTO> returnBookings()
	{
		return clientBookings;
	}

	public void close()
	{

		try
		{
			socket.close();
			oos.close();
			ois.close();
			System.out.println("Connection to the server has been closed");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public ClientDTO getClient() {
		return client;
	}

	@SuppressWarnings("unchecked")
	public void getAllStats() throws ClassNotFoundException, IOException{
		choice(4);
		roomUseStats = (ArrayList<RoomDTO>) ois.readObject();
		roomCancelStats = (ArrayList<RoomCancellationsDTO>) ois.readObject();		
		equipmentStats = (ArrayList<RoomEquipmentDTO>) ois.readObject();
		bookingsForStats = (ArrayList<BookingDTO>) ois.readObject();

	}

	public ArrayList<RoomDTO> getRoomUseStats() throws ClassNotFoundException, IOException{
		return roomUseStats;
	}
	public ArrayList<RoomEquipmentDTO> getRoomEquipmentStats() throws ClassNotFoundException, IOException{
		return equipmentStats;
	}

	public void confirmBooking(String clientName, String clientSurname, String roomName, String date) {
		choice(10);
		try 
		{
			oos.writeUTF(clientName);
			oos.flush();
			oos.writeUTF(clientSurname);
			oos.flush();
			oos.writeUTF(roomName);
			oos.flush();
			oos.writeUTF(date);
			oos.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	public void updateWaitingList(String roomName, String date){
		try {
			choice(11);
			oos.writeUTF(roomName);
			oos.flush();
			oos.writeUTF(date);
			oos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<WaitingListDTO> getAllOnWaitList() throws ClassNotFoundException, IOException{
		choice(9);
		return (ArrayList<WaitingListDTO>) ois.readObject();
	}

	public static ClientFX getInstance() {
		return clientFX;
	}
	public void addNewClient(String name, String surname, String title, String cellNo, String email,
			String dept, String password, boolean status) throws IOException {
		choice(7);
		ClientDTO addClient = new ClientDTO(name, surname, title, cellNo, email, dept, password, status);
		oos.writeObject(addClient);
		oos.flush();
		
	}
	@SuppressWarnings("unchecked")
	public ArrayList<RoomReportDTO> getRoomReportsPercentage(String date, int choose) throws IOException, ClassNotFoundException{
		choice(14);
		oos.writeInt(choose);
		oos.flush();
		oos.writeUTF(date);
		oos.flush();
		ArrayList<RoomReportDTO> temp = (ArrayList<RoomReportDTO>) ois.readObject();
		return temp;
	}
	public void forgotPassword(String string) {
		try {
			choice(15);
			oos.writeUTF(string);
			oos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

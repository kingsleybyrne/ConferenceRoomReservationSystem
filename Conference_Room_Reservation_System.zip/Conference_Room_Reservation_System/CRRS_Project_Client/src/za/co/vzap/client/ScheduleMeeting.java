package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ScheduleMeeting extends JPanel implements ActionListener {
	private JPanel scheduleMeetingPanel;
	private JPanel nPanel;
	private JLabel lblScheduleMeeting;
	private JPanel equpmentPanel;
	private JLabel lblSelectEquipment;
	private JComboBox equipmentBox;
	private JButton addEquipmentBtn;
	private JTable equipmentTable;
	private JScrollPane scrollPane;
	private JButton removeBtn;
	private JLabel lblCurrentlyInMeeting;
	private JPanel descriptionPanel;
	private JTextArea descriptionArea;
	private JButton scheduleMeetingBtn;
	private JLabel lblQuantity;
	private JComboBox quantityBox;
	public static ScheduleMeeting sm = new ScheduleMeeting();
	public ArrayList<String> equipmentList ;
	public ArrayList<String> quantityList ;
	public int count ;
	/**
	 * Create the panel.
	 */
	public ScheduleMeeting() {
		setLayout(null);
		count = 0 ;
		 equipmentList = new ArrayList<String>() ;
		 quantityList = new ArrayList<String>() ;
		scheduleMeetingPanel = new JPanel();
		scheduleMeetingPanel.setBounds(0, 0, 800, 700);
		add(scheduleMeetingPanel);
		scheduleMeetingPanel.setLayout(null);
		
		nPanel = new JPanel();
		nPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		nPanel.setBounds(0, 0, 198, 59);
		scheduleMeetingPanel.add(nPanel);
		nPanel.setLayout(null);
		
		lblScheduleMeeting = new JLabel("Schedule Meeting");
		lblScheduleMeeting.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblScheduleMeeting.setBounds(10, 22, 140, 26);
		nPanel.add(lblScheduleMeeting);
		
		equpmentPanel = new JPanel();
		equpmentPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Equipment", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))));
		equpmentPanel.setBounds(36, 153, 555, 220);
		scheduleMeetingPanel.add(equpmentPanel);
		equpmentPanel.setLayout(null);
		
		lblSelectEquipment = new JLabel("Select equipment :");
		lblSelectEquipment.setBounds(10, 30, 113, 14);
		equpmentPanel.add(lblSelectEquipment);
		
		equipmentBox = new JComboBox();
		equipmentBox.setModel(new DefaultComboBoxModel(new String[] {"AirCon", "Chair", "Clock", "Coffee", "Complimentary Treats", "Computer Mouse", "Extenstion Cable", "Fan", "HDMI Cable", "Heater", "Kettle", "Laptop", "Large Table", "Laser Pointer", "Medium Table", "Microphone", "Microphone Stand", "Mugs", "Network Cable", "Notepad", "PA System", "Pen", "Projector", "Slide Projector", "Small Table", "Sound Amplifier", "Speaker", "Tape Recorder", "Tea", "Television", "Video Cassette Recorder", "Water Bottle", "White Board"}));
		equipmentBox.setBounds(124, 27, 178, 20);
		equpmentPanel.add(equipmentBox);
		
		addEquipmentBtn = new JButton("Add Equipment");
		addEquipmentBtn.addActionListener(this);
		addEquipmentBtn.setBounds(381, 88, 135, 23);
		equpmentPanel.add(addEquipmentBtn);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 72, 361, 137);
		equpmentPanel.add(scrollPane);
		
		equipmentTable = new JTable();
		scrollPane.setViewportView(equipmentTable);
		equipmentTable.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"Equipment", "Quantity"
			}
		));
		
		removeBtn = new JButton("Remove Equipment");
		removeBtn.addActionListener(this);
		removeBtn.setBounds(373, 142, 153, 23);
		equpmentPanel.add(removeBtn);
		
		lblCurrentlyInMeeting = new JLabel("Currently in meeting room :");
		lblCurrentlyInMeeting.setBounds(10, 55, 201, 14);
		equpmentPanel.add(lblCurrentlyInMeeting);
		
		lblQuantity = new JLabel("Quantity :");
		lblQuantity.setBounds(331, 30, 78, 14);
		equpmentPanel.add(lblQuantity);
		
		quantityBox = new JComboBox();
		quantityBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		quantityBox.setBounds(419, 27, 37, 20);
		equpmentPanel.add(quantityBox);
		
		descriptionPanel = new JPanel();
		descriptionPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Meeting Description", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))));
		descriptionPanel.setBounds(36, 84, 526, 58);
		scheduleMeetingPanel.add(descriptionPanel);
		descriptionPanel.setLayout(null);
		
		descriptionArea = new JTextArea();
		descriptionArea.setBounds(10, 25, 339, 22);
		descriptionPanel.add(descriptionArea);
		
		scheduleMeetingBtn = new JButton("Finalize Details");
		scheduleMeetingBtn.addActionListener(e -> Controller.getInstance().book());
		scheduleMeetingBtn.setBounds(252, 384, 138, 23);
		scheduleMeetingPanel.add(scheduleMeetingBtn);
		equipmentTable.getColumnModel().getColumn(1).setMaxWidth(100);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == addEquipmentBtn)
		{
			String equipment = (String)equipmentBox.getSelectedItem();
			String quantity = (String)quantityBox.getSelectedItem();
			
			equipmentList.add(equipment);
			
			quantityList.add(quantity);
			
			equipmentTable.getModel().setValueAt(equipment, count, 0);
			equipmentTable.getModel().setValueAt(quantity, count, 1);
			count++;
			
			
			
		}
		if(source == removeBtn)
		{
			int equipmentToRemove = equipmentTable.getSelectedRow();
			int modelRow = equipmentTable.convertRowIndexToModel(equipmentToRemove);
			DefaultTableModel model = (DefaultTableModel)equipmentTable.getModel();
			model.removeRow(modelRow);
			count = count - 1 ;
			
		}
		
	}
	
	public ArrayList<String> getAllEquipment(){
		return equipmentList;
	}
	
	public ArrayList<Integer> getEquipmentQuantity(){
		ArrayList<Integer> ai = new ArrayList<Integer>();
		for(String st : quantityList){
			ai.add(Integer.parseInt(st));
		}
		return ai;
	}
	
	public JPanel returnScheduleMeeting()
	{
		return sm ;
	}
	
	public String getMeetingDescriptionArea(){
		return descriptionArea.getText();
	}

}

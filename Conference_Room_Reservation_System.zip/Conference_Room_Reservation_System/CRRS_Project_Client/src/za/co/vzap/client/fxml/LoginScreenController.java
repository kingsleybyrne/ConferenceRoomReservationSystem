package za.co.vzap.client.fxml;

import java.io.IOException;
import java.util.Optional;

import javax.swing.SwingUtilities;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;

import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.client.fx.SendForgotPassword;
import za.co.vzap.dto.ClientDTO;
import za.co.vzap.face.FaceSimilarity;

public class LoginScreenController {
	
	@FXML
	private JFXButton login;
	@FXML
	private JFXButton signup;
	@FXML
	private JFXTextField email;
	@FXML
	private JFXPasswordField password;
	private Scene createAccountScreen;
	private static Scene homeScreen;
	
	public void validate() throws IOException{
		
        
		ClientFX.getInstance().choice(1);
		ClientDTO myClient = ClientFX.getInstance().login(email.getText(), password.getText());
		if(myClient!=null){	        
			Parent phomeScreen = FXMLLoader.load(getClass().getResource("HomeScreen.fxml"));
			homeScreen = new Scene(phomeScreen);
			MainStage.getStage().setScene(homeScreen);
			email.setText("");
			password.setText("");		
		} else {
			int a = AlertBox.display("Invalid Details", "Please Re-Enter Details", "Ok", "Exit");
			if(a == 0){
				email.setText("");
				password.setText("");
			} else {
				System.exit(0);
			}
		}
	}
	public void signUpPage() throws IOException{
//		facialRec();
		Parent pSignUpPage = FXMLLoader.load(getClass().getResource("CreateAccount.fxml"));
		createAccountScreen = new Scene(pSignUpPage);
		MainStage.getStage().setScene(createAccountScreen);
	}
	
	public static Scene getHomeScreen(){
		return homeScreen;
	}
	
	public void forgotPassword()
	{
		TextInputDialog dialog = new TextInputDialog("");
		dialog.setTitle("Retrieve a forgotten password");
		dialog.setHeaderText("Provide your email address below");
		dialog.setContentText("Please enter your email address:");

		// Traditional way to get the response value.
		Optional<String> result = dialog.showAndWait();
		if (result.isPresent()){
//		    System.out.println("Your email address: " + result.get()); //Kinglsey must create method to send email to this person with their password attached !!!
		   ClientFX.getInstance().forgotPassword(result.get());
		}
		
	}
	public void facialRec(){
		
		try {
			if(FaceSimilarity.faceSimilarity()){
				ClientDTO myClient = ClientFX.getInstance().login("kingsley.r.bryne@gmail.com", "kingsley");
				
				Parent phomeScreen = FXMLLoader.load(getClass().getResource("HomeScreen.fxml"));
				homeScreen = new Scene(phomeScreen);
				MainStage.getStage().setScene(homeScreen);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
}

package za.co.vzap.client.fx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.*;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TST extends Application {
	TableView<AddEquip> table;
	
	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Leviathon");
		
		TableColumn<AddEquip, String> nameColumn = new TableColumn<>("Name");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("s"));
		
		TableColumn<AddEquip, String> nextColumn = new TableColumn<>("Next");
		nextColumn.setMinWidth(200);
		nextColumn.setCellValueFactory(new PropertyValueFactory<>("t"));
		
		table = new TableView<>();
		table.setItems(getData());
		table.getItems().add(new AddEquip("WASSUP", "TEST"));
		
		
		table.getColumns().addAll(nameColumn, nextColumn);
		
		VBox layout = new VBox();
		layout.getChildren().addAll(table);
		Scene scene = new Scene(layout);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private ObservableList<AddEquip> getData() {
		ObservableList<AddEquip> prod = FXCollections.observableArrayList();
		prod.add(new AddEquip("test", "1"));
		prod.add(new AddEquip("ewvatd", "srtb"));
		prod.add(new AddEquip("setbdtygn", "tbgf"));
		prod.add(new AddEquip("rtnfbgv", "cesxer"));
		prod.add(new AddEquip("tdrbf", "xwres"));
		return prod;
	}

	public static void main(String[] args) {
		launch(args);

	}
}

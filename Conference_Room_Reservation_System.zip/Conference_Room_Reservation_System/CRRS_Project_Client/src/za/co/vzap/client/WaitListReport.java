package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.border.BevelBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;

public class WaitListReport extends JPanel implements MouseListener {
	private JPanel waitListPanel;
	private JPanel panel;
	private JLabel lblWaitListReport;
	private JTable waitListTable;
	private JScrollPane scrollPane;
	private JButton waitListChartBtn;
	public static WaitListReport wlr = new WaitListReport();
	private JButton return2ReportBtn;

	/**
	 * Create the panel.
	 */
	public WaitListReport() {
		
		waitListPanel = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(waitListPanel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 628, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(waitListPanel, GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)
		);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		scrollPane = new JScrollPane();
		
		waitListChartBtn = new JButton("View Wait List Chart");
		waitListChartBtn.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		return2ReportBtn = new JButton("> Return to Report Page");
		return2ReportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayReportPage();
			}
		});
		GroupLayout gl_waitListPanel = new GroupLayout(waitListPanel);
		gl_waitListPanel.setHorizontalGroup(
			gl_waitListPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_waitListPanel.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 220, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(154, Short.MAX_VALUE))
				.addGroup(gl_waitListPanel.createSequentialGroup()
					.addContainerGap(401, Short.MAX_VALUE)
					.addComponent(return2ReportBtn)
					.addGap(74))
				.addGroup(Alignment.LEADING, gl_waitListPanel.createSequentialGroup()
					.addGap(25)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 392, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(211, Short.MAX_VALUE))
				.addGroup(Alignment.LEADING, gl_waitListPanel.createSequentialGroup()
					.addGap(176)
					.addComponent(waitListChartBtn)
					.addContainerGap(309, Short.MAX_VALUE))
		);
		gl_waitListPanel.setVerticalGroup(
			gl_waitListPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_waitListPanel.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
					.addGap(19)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(waitListChartBtn)
					.addGap(38)
					.addComponent(return2ReportBtn)
					.addContainerGap(43, Short.MAX_VALUE))
		);
		
		waitListTable = new JTable();
		waitListTable.addMouseListener(this);
		waitListTable.setToolTipText("Select the Employee from the table to display which equipment they requested for the specified room");
		waitListTable.setCellSelectionEnabled(true);
		scrollPane.setViewportView(waitListTable);
		waitListTable.setModel(new DefaultTableModel(
			new Object[][] {
				{"Graham", "Amazon", "2018/07/18", "08:00 AM"},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"Employee", "Room", "Date", "Time"
			}
		));
		
		lblWaitListReport = new JLabel("Wait List Report");
		lblWaitListReport.setFont(new Font("Tahoma", Font.BOLD, 15));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblWaitListReport)
					.addContainerGap(164, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addContainerGap(25, Short.MAX_VALUE)
					.addComponent(lblWaitListReport)
					.addGap(23))
		);
		panel.setLayout(gl_panel);
		waitListPanel.setLayout(gl_waitListPanel);
		setLayout(groupLayout);

	}
	public JPanel returnWaitListReport() {
		return wlr;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		Object source = e.getSource();
		if(source == waitListTable)
		{
			int rowSelected = waitListTable.getSelectedRow();
			String info = "Details of employee on the wait list  \n";
					info += "Employee : " + (String) waitListTable.getValueAt(rowSelected,0 ) + "\n Room :" + (String) waitListTable.getValueAt(rowSelected,1 ) + "\n Date : " + (String) waitListTable.getValueAt(rowSelected,2 ) + "\n Time : " + (String) waitListTable.getValueAt(rowSelected,3 ) + "\n Equipment requested :" ;
			JOptionPane.showMessageDialog(this, info  );
		}
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

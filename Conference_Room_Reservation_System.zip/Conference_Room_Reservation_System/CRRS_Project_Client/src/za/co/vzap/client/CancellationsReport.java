package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;

public class CancellationsReport extends JPanel {
	private JPanel cancellationsPanel;
	private JPanel panel;
	private JLabel lblCancellationsReport;
	private JTable cancellationsTable;
	private JScrollPane scrollPane;
	private JButton viewCancelChartBtn;
	public static CancellationsReport cr = new CancellationsReport();

	/**
	 * Create the panel.
	 */
	public CancellationsReport() {
		
		cancellationsPanel = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(cancellationsPanel, GroupLayout.PREFERRED_SIZE, 637, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(cancellationsPanel, GroupLayout.PREFERRED_SIZE, 405, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		scrollPane = new JScrollPane();
		
		viewCancelChartBtn = new JButton("View Cancellation Chart");
		viewCancelChartBtn.addActionListener(e->{
			try {
				Controller.getInstance().displayCancellationsChart();;
			} catch (ClassNotFoundException | SQLException | IOException e1) {
				
				e1.printStackTrace();
			}
		});
		viewCancelChartBtn.setFont(new Font("Tahoma", Font.PLAIN, 12));
		GroupLayout gl_cancellationsPanel = new GroupLayout(cancellationsPanel);
		gl_cancellationsPanel.setHorizontalGroup(
			gl_cancellationsPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_cancellationsPanel.createSequentialGroup()
					.addGroup(gl_cancellationsPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 220, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_cancellationsPanel.createSequentialGroup()
							.addGap(135)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 412, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(90, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_cancellationsPanel.createSequentialGroup()
					.addContainerGap(282, Short.MAX_VALUE)
					.addComponent(viewCancelChartBtn)
					.addGap(266))
		);
		gl_cancellationsPanel.setVerticalGroup(
			gl_cancellationsPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_cancellationsPanel.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)
					.addGap(27)
					.addComponent(viewCancelChartBtn)
					.addContainerGap(87, Short.MAX_VALUE))
		);
		
		cancellationsTable = new JTable();
		scrollPane.setViewportView(cancellationsTable);
		cancellationsTable.setModel(new DefaultTableModel(
			new Object[][] {
				{"Amazon", null},
				{"Congo", null},
				{"Ebro", null},
				{"Ganges", null},
				{"Mississippi", null},
				{"Mosman", null},
				{"Nile", null},
				{"Ottawa", null},
				{"Rhine", null},
				{"Seine", null},
				{"Thames", null},
				{null, null},
			},
			new String[] {
				"Room", "Number of Cancellations"
			}
		));
		
		lblCancellationsReport = new JLabel("Cancellations Report");
		lblCancellationsReport.setFont(new Font("Tahoma", Font.BOLD, 15));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblCancellationsReport)
					.addContainerGap(160, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(22)
					.addComponent(lblCancellationsReport)
					.addContainerGap(24, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		cancellationsPanel.setLayout(gl_cancellationsPanel);
		setLayout(groupLayout);

	}
	public JPanel returnCancellationsReport() {
		return cr;
	}

}

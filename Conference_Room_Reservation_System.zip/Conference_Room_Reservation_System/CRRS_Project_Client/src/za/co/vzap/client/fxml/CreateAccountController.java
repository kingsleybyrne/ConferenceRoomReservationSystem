package za.co.vzap.client.fxml;


import java.awt.event.KeyListener;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import com.jfoenix.controls.JFXButton;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyEvent;
import za.co.vzap.client.Controller;
import za.co.vzap.client.fx.ClientFX;

public class CreateAccountController implements Initializable  {

	@FXML
	private TextField nameJTF  , surnameJTF ,cellNoJTF, emailJTF , email2JTF , passwordJTF, password2JTF = null ;
	@FXML
	private ChoiceBox titleBox , deptBox , userBox;
	@FXML
	private JFXButton createProfile;
	@FXML
	private JFXButton goBack;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		//Methods come in here 
		setUserBox();
		setDeptBox();
		setTitleBox();
		checkValidInput();
		setToolTips();
		
//		try {
//			checkFieldsValid();
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}

	}
	public boolean validate(){
		if(nameJTF.getText().equals("") || surnameJTF.getText().equals("") || cellNoJTF.getText().equals("") || emailJTF.getText().equals("") || email2JTF.getText().equals("") || passwordJTF.getText().equals("") || password2JTF.getText().equals("") )
		{
		
			AlertBox.display("Invalid Details", "Fill in all the required fields as stipulated by *", "Ok");
			return false;
		} else {
			if(!(emailJTF.getText().equals(email2JTF.getText())))
			{
				AlertBox.display("Email verification failed !", "Email does not match !", "Ok", "Exit");
				emailJTF.setText("");
				email2JTF.setText("");
				return false;
			} else {
				if(!(passwordJTF.getText().equals(password2JTF.getText())))
				{
					AlertBox.display("Password verification failed !", "Password does not match !", "Ok", "Exit");
					password2JTF.setText("");
					passwordJTF.setText("");
					return false;
				} 
			}
		}
		return true;
		
		
	}
	public void checkFieldsValid() throws IOException
	{
		
		if(validate()){
			String name =nameJTF.getText();
			String surname = surnameJTF.getText();
			String title = (String)titleBox.getSelectionModel().getSelectedItem();
			String cellNo = cellNoJTF.getText();
			String email = emailJTF.getText();
			String dept = (String) deptBox.getSelectionModel().getSelectedItem();
			String password = passwordJTF.getText();


			//ClientDTO newClient = new ClientDTO(name, surname, title, cellNo, email, dept,password,isExecutive);

			addNewClient();
			Parent phomeScreen = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
			Scene loginScreen = new Scene(phomeScreen);
			MainStage.getStage().setScene(loginScreen);
		}


}

	private void addNewClient() throws IOException {

		if(userBox.getSelectionModel().getSelectedItem().equals("Executive"))
		{
			ClientFX.getInstance().addNewClient(nameJTF.getText(), surnameJTF.getText(), (String)titleBox.getSelectionModel().getSelectedItem(),cellNoJTF.getText(), emailJTF.getText(), (String)deptBox.getSelectionModel().getSelectedItem(), passwordJTF.getText(), true);
		}
		else
		{
			ClientFX.getInstance().addNewClient(nameJTF.getText(), surnameJTF.getText(), (String)titleBox.getSelectionModel().getSelectedItem(),cellNoJTF.getText(), emailJTF.getText(), (String)deptBox.getSelectionModel().getSelectedItem(), passwordJTF.getText(), false);
		
		}	

	}


	public void setUserBox()
	{
		if(userBox != null)
		{
			userBox.getItems().clear();
			userBox.getItems().addAll("Employee" , "Executive");
		}
		else
		{
			userBox.getItems().addAll("Employee" , "Executive");
		}
	}
	public void setDeptBox()
	{
		if(deptBox != null)
		{
			deptBox.getItems().clear();
			deptBox.getItems().addAll("Accounting" , "Call Centre" , "Catering" , "Education" , "Engineering" , "HR" , "IT" , "Law" , "Logistics" , "Management" , "Marketing" , "Production" , "R&D", "Sales" , "Security");


		}
		else
		{
			deptBox.getItems().addAll("Accounting" , "Call Centre" , "Catering" , "Education" , "Engineering" , "HR" , "IT" , "Law" , "Logistics" , "Management" , "Marketing" , "Production" , "R&D", "Sales" , "Security");

		}

	}
	public void setTitleBox()
	{
		if(titleBox != null)
		{
			titleBox.getItems().clear();
			titleBox.getItems().addAll("Mr", "Miss" , "Mrs", "Dr" , "Prof" );

		}
		else
		{
			titleBox.getItems().addAll("Mr", "Miss" , "Mrs", "Dr" , "Prof" );

		}

	}
	public void checkValidInput()
	{
		nameJTF.setOnKeyTyped(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent ke){
				String c = ke.getCharacter();
				int len = c.length();
				for(int i = 0 ;i < len ; i++)
				{
					Character cc = c.charAt(i);
				if(!(Character.isLetter(cc)))
				{
					ke.consume();
				}
				}
			}
		});
		
		surnameJTF.setOnKeyTyped(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent ke){
				String c = ke.getCharacter();
				int len = c.length();
				for(int i = 0 ;i < len ; i++)
				{
					Character cc = c.charAt(i);
				if(!(Character.isLetter(cc)))
				{
					ke.consume();
				}
				}
			}
		});
		
		cellNoJTF.setOnKeyTyped(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent ke){
				String c = ke.getCharacter();
				int len = c.length();
				for(int i = 0 ;i < len ; i++)
				{
					Character cc = c.charAt(i);
					if(!(Character.isDigit(cc)))
				{
					ke.consume();
				}
				}
			}
		});
		passwordJTF.setOnKeyTyped(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent ke){
				String c = ke.getCharacter();
				int len = c.length();
				for(int i = 0 ;i < len ; i++)
				{
					Character cc = c.charAt(i);
				if(!(Character.isLetterOrDigit(cc)))
				{
					ke.consume();
				}
					
				}
			}
		});
		password2JTF.setOnKeyTyped(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent ke){
				String c = ke.getCharacter();
				int len = c.length();
				for(int i = 0 ;i < len ; i++)
				{
					Character cc = c.charAt(i);
					if(!(Character.isLetterOrDigit(cc)))
				{
					ke.consume();
				}
				}
			}
		});
		
	}
	public void gotoLogin(){
		MainStage.getStage().setScene(MainStage.getLoginScreen());
	}
	public void setToolTips()
	{
		Tooltip toolTip = new Tooltip();
		toolTip.setText("Field for your name");
		nameJTF.setTooltip(toolTip); 
		
		Tooltip toolTip2 = new Tooltip();
		toolTip2.setText("Field for your surname");
		surnameJTF.setTooltip(toolTip2);
		
		Tooltip toolTip3 = new Tooltip();
		toolTip3.setText("Field for your cellphone number");
		cellNoJTF.setTooltip(toolTip3);
		
		Tooltip toolTip4 = new Tooltip();
		toolTip4.setText("Field for your email address");
		emailJTF.setTooltip(toolTip4);
		
		Tooltip toolTip5 = new Tooltip();
		toolTip5.setText("Field to confirm your email address");
		email2JTF.setTooltip(toolTip5);
		
		Tooltip toolTip6 = new Tooltip();
		toolTip6.setText("Field for your password");
		passwordJTF.setTooltip(toolTip6);
		
		Tooltip toolTip7 = new Tooltip();
		toolTip7.setText("Field to confirm your password");
		password2JTF.setTooltip(toolTip7);
		
		Tooltip toolTip8 = new Tooltip();
		toolTip8.setText("Field to select your title");
		titleBox.setTooltip(toolTip8);
		
		Tooltip toolTip9 = new Tooltip();
		toolTip9.setText("Field to select your department");
		deptBox.setTooltip(toolTip9);
		
		Tooltip toolTip0 = new Tooltip();
		toolTip0.setText("Field to select your authority level");
		userBox.setTooltip(toolTip0);
		
		
		
		 
		
		 
		 
	}

}

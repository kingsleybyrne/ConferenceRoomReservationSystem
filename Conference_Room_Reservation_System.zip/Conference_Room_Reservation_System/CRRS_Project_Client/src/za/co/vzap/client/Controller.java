package za.co.vzap.client;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;

import za.co.vzap.client.main.ClientMain;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.ClientDTO;
import za.co.vzap.dto.RoomDTO;
import za.co.vzap.graph.StatsBarGraphEquipmentUse;
import za.co.vzap.graph.StatsBarGraphRoomCancellations;
import za.co.vzap.graph.StatsBarGraphRoomUse;
import za.co.vzap.graph.StatsRoomUsePieChart;

public class Controller {
	private static Controller instance = null;
	private Vector<String> listOfBookings;
	private ClientMain client;
	private int count = 0;
	
	private Controller(){
		this.client = new ClientMain();
	}
	
	public static Controller getInstance() {
		if(instance==null){//singleton pattern
			synchronized (Controller.class){
				if(instance==null){
					instance = new Controller();
				}
			}
		}
		return instance;
	}
	
	public void setBookings(ArrayList<BookingDTO> bookingsList){
		listOfBookings = null;
		listOfBookings = new Vector<String>();
		for(int i = 0; i < bookingsList.size(); i++){
			String temp = bookingsList.get(i).getRoomName();
			temp = temp + " - " + bookingsList.get(i).getStartDate();
			if(bookingsList.get(i).isBooked().equalsIgnoreCase("pending")){
				listOfBookings.addElement(temp);
			}
		}
	}

	public void validate(String text, char[] password) {
		String a = text;
		String b = new String(password);
		client.choice(1);
		if(client.login(a, b) != null){			
			MainFrame.addToFrame(MainMenu.main.getInstance());
			LoginPanel.login.clearFields();
			try {
				setBookings(client.returnBookings());
				client.getAllStats();
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}
		} else {
			JOptionPane.showMessageDialog(LoginPanel.login.getInstance(), "Try again");
			LoginPanel.login.clearFields();
		}		
	}
	
	public Vector<String> returnBookings(){
		return listOfBookings;
	}

	public void searchDetails(String text) {
		try {
			client.searchForRoom(text);	
			String bookedByTxt = "";
			String noOfAtt = "";
			String purpose = "";
			for(ClientDTO cl : client.getClientThatBooked()){
				for(int i = 0; i < client.getBookingDetails().size(); i++){
					if(cl.getisExecutive() && !(client.getClient().getisExecutive())){
						bookedByTxt += (i+1) + ") " + "Room Unavailable!" + "\n";
						noOfAtt += (i+1) + ") " + "Room Unavailable!" + "\n";
						purpose += (i+1) + ") " + "Room Unavailable!" + "\n";
					} else {
						bookedByTxt += (i+1) + ") " + client.getBookingDetails().get(i).getClientName() + "\n";
						noOfAtt += (i+1) + ") " + client.getBookingDetails().get(i).getNoOfAttendees() + "\n";
						purpose += (i+1) + ") " + client.getBookingDetails().get(i).getMeetingDescription() + "\n";
					}	
				}
			}
			
			MainMenu.main.setBookedByText(bookedByTxt);
			MainMenu.main.setNoOfAttendeesText(noOfAtt);
			MainMenu.main.setPurposeText(purpose);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void displayStats() throws ClassNotFoundException, IOException, SQLException{//can take in an action event and so one method for all stats????
		ArrayList<RoomDTO> list = client.getRoomUseStats();
		StatsRoomUsePieChart.setList(list);
		StatsRoomUsePieChart roomUsePie = new StatsRoomUsePieChart();
		StatsBarGraphRoomUse barRoomUse = new StatsBarGraphRoomUse(StatsBarGraphRoomUse.createDataset(list));
		StatsBarGraphRoomCancellations roomCancel = new StatsBarGraphRoomCancellations(StatsBarGraphRoomCancellations.createDataset(client.getRoomCancleStats()));
		StatsBarGraphEquipmentUse equipUse = new StatsBarGraphEquipmentUse(StatsBarGraphEquipmentUse.createDataset(client.getRoomEquipmentStats()));
		if(count == 4){
			count = 0;
		}
		if(count == 0){
			MainMenu.main.setCenterPanel(roomUsePie);
		}
		if(count == 1){
			MainMenu.main.setCenterPanel(barRoomUse);
		}
		if(count == 2){
			MainMenu.main.setCenterPanel(roomCancel);
		}
		if(count == 3){
			MainMenu.main.setCenterPanel(equipUse);
		}
		count += 1;
	}
	
	public void book(){
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		BookingDTO booking = new BookingDTO(client.getClient().getClientName(), client.getClient().getClientSurname(), 
				"2018-07-20 10:00:00", 
				"2018-07-20 12:00:00", "booked", Questionnaire.ques.getRoom(),ScheduleMeeting.sm.getMeetingDescriptionArea(), Questionnaire.ques.getNoOfAtt());
		client.book(booking, ScheduleMeeting.sm.getAllEquipment(), ScheduleMeeting.sm.getEquipmentQuantity());
	}
	
	public void displayRoomReport()
	{
		MainFrame.addToFrame(RoomReport.rr.returnRoomReport());
	}
	public void displayEquipmentReport()
	{
		MainFrame.addToFrame(EquipmentReport.er.returnEquipmentReport());
	}
	public void displayWaitListReport()
	{
		MainFrame.addToFrame(WaitListReport.wlr.returnWaitListReport());
	}
	public void displayCancellationsReport()
	{
		MainFrame.addToFrame(CancellationsReport.cr.returnCancellationsReport());
	}
	public void displayReportPage()
	{
		MainFrame.addToFrame(ReportPage.rp.returnReportPage());
	}
	public void displayRoomChart() throws ClassNotFoundException, SQLException, IOException
	{
		StatsBarGraphRoomUse roomGraph = new StatsBarGraphRoomUse(StatsBarGraphRoomUse.createDataset(client.getRoomUseStats()));
		MainFrame.addToFrame(roomGraph);
	}
	public void displayEquipmentChart() throws ClassNotFoundException, SQLException, IOException
	{
		StatsBarGraphEquipmentUse equipmentGraph = new StatsBarGraphEquipmentUse(StatsBarGraphEquipmentUse.createDataset(client.getRoomEquipmentStats()));
		MainFrame.addToFrame(equipmentGraph);
	}
	public void displayCancellationsChart() throws ClassNotFoundException, SQLException, IOException
	{
		StatsBarGraphRoomCancellations cancellationsGraph = new StatsBarGraphRoomCancellations(StatsBarGraphRoomCancellations.createDataset(client.getRoomCancleStats()));
		MainFrame.addToFrame(cancellationsGraph);	
	}
	public void displayScheduleMeeting()
	{
		MainFrame.addToFrame(ScheduleMeeting.sm.returnScheduleMeeting());
	}


	
	public void closeWindowAndStreams() {
		client.choice(7);
	}
	
	private List<Date> getDaysBetween(Date start, Date end) throws ParseException{
		List<Date> dates = new ArrayList<Date>();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(start);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		while(calendar.getTime().before(end)){
			Date result = df.parse(df.format(calendar.getTime()));
			dates.add(result);
			calendar.add(Calendar.DATE, 1);
		}
		return dates;
	}

	public void searchRoomsAvail() {
		try {
			client.searchRooms(Questionnaire.ques.getNoOfAtt());
			ArrayList<BookingDTO> booking = client.getBookingsOnRooms();
			ArrayList<RoomDTO> rooms = client.getRoomsAvailable();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat formatter = new SimpleDateFormat("HH:mm");
			Date fromDate = df.parse(df.format(Questionnaire.ques.getFromDate()));
			Date toDate = df.parse(df.format(Questionnaire.ques.getToDate()));
			ArrayList<Date> range = (ArrayList<Date>) getDaysBetween(fromDate, toDate);
			System.out.println(fromDate + "\n" + toDate + "\n" + range.size());
			
			Date clientStartTime = (Date) formatter.parse(Questionnaire.ques.getStartTime().substring(0, 5));
			Date clientEndTime = (Date) formatter.parse(Questionnaire.ques.getEndTime().substring(0, 5));
//******************************************************************************************************************************************************			
			for(int i = 0; i < range.size(); i++){
				if(booking.size() == 0){
					for(int a = 0; a < rooms.size(); a++){
						Questionnaire.ques.addRoomsToTable(rooms.get(a).getRoomName(), "Available", df.format(range.get(i)));
						System.out.println("bookings == 0");
					}
				} else {
					for(int j = 0; j < rooms.size(); j++){
						
						for(int k = 0; k < booking.size(); k++){
							
							if(rooms.get(j).getRoomName().equals(booking.get(k).getRoomName())){
								
								if(!Questionnaire.ques.getStartTime().substring(0, 5).equals(booking.get(k).getStartDate().substring(11, 16))){
									
									Date bookingStartTime = (Date) formatter.parse(booking.get(k).getStartDate().substring(11, 16));
									Date bookingEndTime = (Date) formatter.parse(booking.get(k).getEndDate().substring(11, 16));
									
									if(!(clientStartTime.after(bookingStartTime) && clientStartTime.before(bookingEndTime))){
										if(!(clientEndTime.after(bookingStartTime) && clientEndTime.before(bookingEndTime))){
											Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Available", df.format(range.get(i)));
										} else {
											Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Booked", df.format(range.get(i)));
										}
									} else {
										if(!(clientEndTime.after(bookingStartTime) && clientEndTime.before(bookingEndTime))){
											Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Available", df.format(range.get(i)));
										} else {
											Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Booked", df.format(range.get(i)));
										}
									}
								} else {
									Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Booked", df.format(range.get(i)));
								}
							} else {
								Questionnaire.ques.addRoomsToTable(rooms.get(j).getRoomName(), "Available", df.format(range.get(i)));
							}
						}
					}
				}
			}
			
		} catch (ClassNotFoundException | IOException | ParseException e) {
			e.printStackTrace();
		}
	}

	public void setUserDetails() {
		Questionnaire.ques.setUserDetails(client.getClient().getClientName(),
				client.getClient().getClientSurname(), client.getClient().getClientPhoneNumber(), client.getClient().getDepartment());
	}

	public void cancelBooking(String selectedValue, Date date) {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String dateOfbooking = formatter.format(date);
		Scanner sc = new Scanner(selectedValue);
		sc.useDelimiter(" ");
		String value = sc.next();
		sc.close();
		client.cancelBooking(client.getClient().getClientName(), client.getClient().getClientSurname(), value);
		
		setBookings(client.returnBookings());
		MainMenu.main.addListData();	
		client.updateWaitingList(value, dateOfbooking);
	}

	public void confirmBooking(String selectedValue) {
		Scanner sc = new Scanner(selectedValue);
		sc.useDelimiter(" ");
		String value = sc.next();
		sc.close();
		client.confirmBooking(client.getClient().getClientName(), client.getClient().getClientSurname(), value);
		setBookings(client.returnBookings());
		MainMenu.main.addListData();
	}	
}

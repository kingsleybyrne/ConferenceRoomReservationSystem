package za.co.vzap.client.fxml;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.ResourceBundle;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.scribe.services.DatatypeConverterEncoder;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.embed.swing.SwingNode;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import za.co.vzap.client.CancellationsReport;
import za.co.vzap.client.EquipmentReport;
import za.co.vzap.client.ReportPage;
import za.co.vzap.client.RoomReport;
import za.co.vzap.client.ScheduleMeeting;
import za.co.vzap.client.WaitListReport;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.client.fx.EquipmentStats;
import za.co.vzap.dto.BookingDTO;
import za.co.vzap.dto.RoomCancellationsDTO;
import za.co.vzap.dto.RoomEquipmentDTO;
import za.co.vzap.dto.RoomReportDTO;
import za.co.vzap.dto.WaitingListDTO;
import za.co.vzap.graph.StatsBarGraphEquipmentUse;
import za.co.vzap.graph.StatsBarGraphRoomCancellations;
import za.co.vzap.graph.StatsBarGraphRoomUse;

public class ReportsController implements Initializable{
	@FXML
	private BorderPane root;
	@FXML
	private BorderPane graphPanel;
	@FXML
	private MenuItem menuHome;
	@FXML
	private MenuItem menuClose;
	@FXML
	private MenuItem menuQuestionnaire;
	@FXML
	private MenuItem menuSearch;
	@FXML
	private MenuItem menuReports;
	@FXML
	private MenuItem menuHelp;
	private static Node printNode;
	@FXML
	private BorderPane tablePanel;
	@FXML
	private DatePicker dateFrom;
	@FXML
	private DatePicker dateTo;
	@FXML
	private JFXButton noOfCancellationsBTN;
	@FXML
	private JFXButton roomOccupationsBTN;
	@FXML
	private JFXButton equipmentListBTN;
	@FXML
	private JFXButton waitlistBTN;
	@FXML
	private JFXButton gotoHome;
	@FXML
	private ChoiceBox<String> reportRange;
	@FXML
	private JFXButton print;

	private LineChart<String, Number> roomCancelLineChart;
	private XYChart.Series<String, Number> series_roomCancelLineChart;

	private TableView<RoomCancellationsDTO> roomCancelTable;
	private TableView<RoomReportDTO> roomOccupationTable;
	private int r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
	private TableView<EquipmentStats> roomEquipmentTable;
	private BarChart<String, Number> equipmentFrequencyBarChart;
	private XYChart.Series<String, Number> series_equipmentFrequencyBarChart;
	private TableView<BookingDTO> waitingListTable;
	private LineChart<String, Number> roomOccupationLineChart;
	private XYChart.Series<String, Number> series_roomOccupationLineChart;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			ClientFX.getInstance().getAllStats();
			createCancellationTable();
			createRoomCancelLineChart();

			createRoomOccupationTable();
			createRoomOccupationLineChart();

			createRoomEquipmentUseTable();
			createEquipmentFrequencyBarChart();
			createWaitingListTable();

		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		print.setOnAction(e -> print());
	}
	public void gotoHomeScreen(){
		MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
	}
	public void displayCancellations() {
		if(dateFrom.getValue()!=null&&dateTo.getValue()!=null){
			try {
				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date dateF = formatter.parse(formatter.format(Date.from(dateFrom.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				Date dateT = formatter.parse(formatter.format(Date.from(dateTo.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				setRoomCancelData(dateF, dateT);

				graphPanel.setCenter(roomCancelLineChart);
				tablePanel.setCenter(roomCancelTable);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			AlertBox.display("Dates", "Please Choose Start And End Dates", "Ok");
		}
	}

	public void displayRoomOccupations() throws ParseException{
		if(dateFrom.getValue()!=null && dateTo.getValue()!=null){
			try {
				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date dateF = formatter.parse(formatter.format(Date.from(dateFrom.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				Date dateT = formatter.parse(formatter.format(Date.from(dateTo.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				setRoomOccupationValues(dateF, dateT);

				graphPanel.setCenter(roomOccupationLineChart);
				tablePanel.setCenter(roomOccupationTable);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			AlertBox.display("Dates", "Please Choose Start And End Dates", "Ok");
		}
	}
	public void displayEquipmentList() {
		if(dateFrom.getValue()!=null && dateTo.getValue()!=null){

			try {
				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date dateF = formatter.parse(formatter.format(Date.from(dateFrom.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				Date dateT = formatter.parse(formatter.format(Date.from(dateTo.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				setEquipmentFrequencyData(dateF, dateT);

				graphPanel.setCenter(equipmentFrequencyBarChart);
				tablePanel.setCenter(roomEquipmentTable);
			} catch (ClassNotFoundException | ParseException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			AlertBox.display("Dates", "Please Choose Start And End Dates", "Ok");
		}
	}

	public void displayWaitList(){
		if(dateFrom.getValue()!=null&&dateTo.getValue()!=null){
			try {
				if(graphPanel.getChildren().size()!=0){
					for(int i = 0; i < graphPanel.getChildren().size(); i++){
						graphPanel.getChildren().remove(i);
					}
				}

				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date dateF = formatter.parse(formatter.format(Date.from(dateFrom.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				Date dateT = formatter.parse(formatter.format(Date.from(dateTo.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
				setWaitlistData(dateF, dateT);
				tablePanel.setCenter(waitingListTable);
			} catch (ClassNotFoundException | IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			AlertBox.display("Dates", "Please Choose Start And End Dates", "Ok");
		}
	}

	public void print(){
		Node n1 = graphPanel.getCenter();
		Node n2 = tablePanel.getCenter();
		if(n1==null && n2!=null){
			PrintingClass.print(n2);
		}
		if(n1!=null && n2!=null){
			PrintingClass.print(n1, n2);
		}
		
	}
	
	public static Node getPane() {
		return printNode;
	}
	
	public void closeTheProgram(){
		MainStage.getStage().close();
		System.exit(0);
	}
	
	
	@SuppressWarnings("unchecked")
	public void createCancellationTable(){
		roomCancelTable = new TableView<>();
		TableColumn<RoomCancellationsDTO, String> nameColumn = new TableColumn<>("Room Name");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("roomName"));

		TableColumn<RoomCancellationsDTO, Integer> cancelColumn = new TableColumn<>("Cancellations");
		cancelColumn.setMinWidth(200);
		cancelColumn.setCellValueFactory(new PropertyValueFactory<>("roomCancellations"));
		roomCancelTable.getColumns().addAll(nameColumn, cancelColumn);
	}
	@SuppressWarnings("unchecked")
	public void createRoomOccupationTable() throws ClassNotFoundException, IOException{
		roomOccupationTable = new TableView<>();
		TableColumn<RoomReportDTO, String> nameColumn = new TableColumn<>("Room Name");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("roomName"));

		TableColumn<RoomReportDTO, Integer> cancelColumn = new TableColumn<>("Percentage Occupation");
		cancelColumn.setMinWidth(200);
		cancelColumn.setCellValueFactory(new PropertyValueFactory<>("percentageFull"));
		roomOccupationTable.getColumns().addAll(nameColumn, cancelColumn);		
	}
	public void createRoomOccupationLineChart(){
		CategoryAxis roomName_xAxis = new CategoryAxis();
		roomName_xAxis.setLabel("Room Name");
		roomName_xAxis.setCategories(FXCollections.<String>observableArrayList(Arrays.asList(
				"Amazon"
				,"Congo"
				,"Ebro"
				,"Ganges"
				,"Missisippi"
				,"Mosman"
				,"Nile"
				,"Ottawa"
				,"Rhine"
				,"Seine"
				,"Thames"
				,"Zambezi"
		)));
		
		NumberAxis roomPercentage_yAxis = new NumberAxis(0, 100, 10);
		roomPercentage_yAxis.setLabel("Percentage Occupied (%)");
		roomOccupationLineChart = new LineChart<>(roomName_xAxis, roomPercentage_yAxis);
		series_roomOccupationLineChart = new XYChart.Series<>();
		roomOccupationLineChart.getStylesheets().add("za/co/vzap/client/fxml/Graph.css");
		
		series_roomOccupationLineChart.setName("Percentage Room Occupations Within A Specified Period");
		roomOccupationLineChart.getData().add(series_roomOccupationLineChart);
	}
	
	public void setRoomOccupationValues(Date fromDate, Date toDate) throws ParseException{
		roomOccupationTable.getItems().clear();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		r1=0;
		r2=0;
		r3=0;
		r4=0;
		r5=0;
		r6=0;
		r7=0;
		r8=0;
		r9=0;
		r10=0;
		r11=0;
		r12=0;
		

		for(BookingDTO book : ClientFX.getInstance().getBookingsForStats()){
			Date bookingDate = formatter.parse(book.getStartDate().substring(0, 10));
			if(book.isBooked().equalsIgnoreCase("Booked")){
				if(bookingDate.after(fromDate)&&bookingDate.before(toDate)){
				
					if(book.getRoomName().equalsIgnoreCase("Amazon")){
						r1+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Congo")){
						r2+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ebro")){
						r3+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ganges")){
						r4+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Missisippi")){
						r5+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Mosman")){
						r6+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Nile")){
						r7+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ottawa")){
						r8+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Rhine")){
						r9+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Seine")){
						r10+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Thames")){
						r11+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Zambezi")){
						r12+=1;
					}
				}
			}	
		}	
		int rTotal = r1+r2+r3+r4+r5+r6+r7+r8+r9+r10+r11+r12;
		
		r1=(int) (((r1+0.0)/(rTotal+0.0)) * 100);
		r2=(int) (((r2+0.0)/(rTotal+0.0)) * 100);
		r3=(int) (((r3+0.0)/(rTotal+0.0)) * 100);
		r4=(int) (((r4+0.0)/(rTotal+0.0)) * 100);
		r5=(int) (((r5+0.0)/(rTotal+0.0)) * 100);
		r6=(int) (((r6+0.0)/(rTotal+0.0)) * 100);
		r7=(int) (((r7+0.0)/(rTotal+0.0)) * 100);
		r8=(int) (((r8+0.0)/(rTotal+0.0)) * 100);
		r9=(int) (((r9+0.0)/(rTotal+0.0)) * 100);
		r10=(int) (((r10+0.0)/(rTotal+0.0)) * 100);
		r11=(int) (((r11+0.0)/(rTotal+0.0)) * 100);
		r12=(int) (((r12+0.0)/(rTotal+0.0)) * 100);
		
		
		int [] roomOcc = new int []{
				r12,
				r1,
				r7,
				r11,
				r5,
				r10,
				r8,
				r3,
				r4,
				r2,
				r6,
				r9};
		try {
			for(int i = 0; i < ClientFX.getInstance().getRoomUseStats().size(); i++){
				series_roomOccupationLineChart.getData().add(new XYChart.Data<String, Number>(ClientFX.getInstance().getRoomUseStats().get(i).getRoomName(), roomOcc[i]));
				roomOccupationTable.getItems().add(new RoomReportDTO("Empty",
						"Empty", 
						ClientFX.getInstance().getRoomUseStats().get(i).getRoomName(), roomOcc[i]));
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
	//room cancellation chart
	public void createRoomCancelLineChart(){
		CategoryAxis roomCancel_xAxis = new CategoryAxis();
		roomCancel_xAxis.setLabel("Room Name");
		roomCancel_xAxis.setCategories(FXCollections.<String>observableArrayList(Arrays.asList(
				"Amazon"
				,"Congo"
				,"Ebro"
				,"Ganges"
				,"Missisippi"
				,"Mosman"
				,"Nile"
				,"Ottawa"
				,"Rhine"
				,"Seine"
				,"Thames"
				,"Zambezi"
		)));
		
		NumberAxis roomCancel_yAxis = new NumberAxis(0, 20, 2);
		roomCancel_yAxis.setLabel("No. Of Cancellations");
		roomCancelLineChart = new LineChart<>(roomCancel_xAxis, roomCancel_yAxis);
		series_roomCancelLineChart = new XYChart.Series<>();
		roomCancelLineChart.getStylesheets().add("za/co/vzap/client/fxml/Graph.css");
		
		series_roomCancelLineChart.setName("No. Of Room Cancellations Within A Specified Period");
		roomCancelLineChart.getData().add(series_roomCancelLineChart);
	}
	//adding data to room cancellation chart and table
	@SuppressWarnings("unchecked")
	public void setRoomCancelData(Date dateFrom, Date dateTo) throws ParseException{
		roomCancelTable.getItems().clear();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		r1=0;
		r2=0;
		r3=0;
		r4=0;
		r5=0;
		r6=0;
		r7=0;
		r8=0;
		r9=0;
		r10=0;
		r11=0;
		r12=0;
		for(BookingDTO book : ClientFX.getInstance().getBookingsForStats()){
			Date bookingDate = formatter.parse(book.getStartDate().substring(0, 10));
			if(book.isBooked().equalsIgnoreCase("Cancelled")){
				if(bookingDate.after(dateFrom)&&bookingDate.before(dateTo)){
				
					if(book.getRoomName().equalsIgnoreCase("Amazon")){
						r1+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Congo")){
						r2+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ebro")){
						r3+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ganges")){
						r4+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Missisippi")){
						r5+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Mosman")){
						r6+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Nile")){
						r7+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Ottawa")){
						r8+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Rhine")){
						r9+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Seine")){
						r10+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Thames")){
						r11+=1;
					}
					if(book.getRoomName().equalsIgnoreCase("Zambezi")){
						r12+=1;
					}
				}
			}		
		}
		int [] roomC = new int []{
		r12,
		r1,
		r7,
		r11,
		r5,
		r10,
		r8,
		r3,
		r4,
		r2,
		r6,
		r9};
	
		try {
			for(int i = 0; i < ClientFX.getInstance().getRoomUseStats().size(); i++){
				series_roomCancelLineChart.getData().add(new XYChart.Data<String, Number>(ClientFX.getInstance().getRoomUseStats().get(i).getRoomName(), roomC[i]));
				roomCancelTable.getItems().add(new RoomCancellationsDTO(ClientFX.getInstance().getRoomUseStats().get(i).getRoomName(), roomC[i]));
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void createRoomEquipmentUseTable() throws ClassNotFoundException, IOException{
		roomEquipmentTable = new TableView<>();
//		RoomEquipmentDTO red = new RoomEquipmentDTO(clientName, clientSurname, roomName, dateStart, dateEnd, roomEquipment, equipmentQuantity);
		TableColumn<EquipmentStats, String> equipmentNameColumn = new TableColumn<>("Equipment Name");
		equipmentNameColumn.setMinWidth(200);
		equipmentNameColumn.setCellValueFactory(new PropertyValueFactory<>("equipmentName"));

		TableColumn<EquipmentStats, Integer> frequencyColumn = new TableColumn<>("Frequency (%)");
		frequencyColumn.setMinWidth(200);
		frequencyColumn.setCellValueFactory(new PropertyValueFactory<>("frequency"));
		roomEquipmentTable.getColumns().addAll(equipmentNameColumn, frequencyColumn);		
	}
	public void createEquipmentFrequencyBarChart(){
		CategoryAxis name_xAxis = new CategoryAxis();
		name_xAxis.setLabel("Equipment");
		name_xAxis.setCategories(FXCollections.<String>observableArrayList(Arrays.asList(
				"Projector"
				,"Video Cassette Recorder"
				,"Television"
				,"White Board"
				,"Tape Recorder"
				,"Slide Projector"
				,"PA System"
				,"Microphone Stand"
				,"Microphone"
				,"Sound Amplifier"
				,"Speaker"
				,"Heater"
				,"Fan"
				,"HDMI Cable"
				,"Extenstion Cable"
				,"Network Cable"
				,"AirCon"
		)));
		
		NumberAxis numbers_yAxis = new NumberAxis(0, 100, 10);
		numbers_yAxis.setLabel("Frequency");
		equipmentFrequencyBarChart = new BarChart<>(name_xAxis, numbers_yAxis);
		equipmentFrequencyBarChart.setPrefHeight(800);
		equipmentFrequencyBarChart.getStylesheets().add("za/co/vzap/client/fxml/Graph.css");
		series_equipmentFrequencyBarChart = new XYChart.Series<>();
		series_equipmentFrequencyBarChart.setName("Percentage Frequency Of Equipment During A Specific Period (%)");
		equipmentFrequencyBarChart.getData().add(series_equipmentFrequencyBarChart);
	}
	@SuppressWarnings("unchecked")
	public void setEquipmentFrequencyData(Date dateFrom, Date dateTo) throws ParseException, ClassNotFoundException, IOException{
		roomEquipmentTable.getItems().clear();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		r1=0;
		r2=0;
		r3=0;
		r4=0;
		r5=0;
		r6=0;
		r7=0;
		r8=0;
		r9=0;
		r10=0;
		r11=0;
		r12=0;
		int r13=0;
		int r14=0;
		int r15=0;
		int r16=0;
		int r17=0;

		for(RoomEquipmentDTO equip : ClientFX.getInstance().getRoomEquipmentStats()){
			Date equipDate = formatter.parse(equip.getDateStart().substring(0, 10));

			if(equipDate.after(dateFrom)&&equipDate.before(dateTo)){

				if(equip.getRoomEquipment().equalsIgnoreCase("Projector")){
					r1+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Video Cassette Recorder")){
					r2+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Television")){
					r3+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("White Board")){
					r4+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Tape Recorder")){
					r5+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Slide Projector")){
					r6+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("PA System")){
					r7+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Microphone Stand")){
					r8+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Microphone")){
					r9+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Sound Amplifier")){
					r10+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Speaker")){
					r11+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Heater")){
					r12+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Fan")){
					r13+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("HDMI Cable")){
					r14+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Extenstion Cable")){
					r15+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("Network Cable")){
					r16+=1;
				}
				if(equip.getRoomEquipment().equalsIgnoreCase("AirCon")){
					r17+=1;
				}
			}		
		}
		int rTotal = r1+r2+r3+r4+r5+r6+r7+r8+r9+r10+r11+r12+r13+r14+r15+r16+r17;
		
		r1=(int) (((r1+0.0)/(rTotal+0.0)) * 100);
		r2=(int) (((r2+0.0)/(rTotal+0.0)) * 100);
		r3=(int) (((r3+0.0)/(rTotal+0.0)) * 100);
		r4=(int) (((r4+0.0)/(rTotal+0.0)) * 100);
		r5=(int) (((r5+0.0)/(rTotal+0.0)) * 100);
		r6=(int) (((r6+0.0)/(rTotal+0.0)) * 100);
		r7=(int) (((r7+0.0)/(rTotal+0.0)) * 100);
		r8=(int) (((r8+0.0)/(rTotal+0.0)) * 100);
		r9=(int) (((r9+0.0)/(rTotal+0.0)) * 100);
		r10=(int) (((r10+0.0)/(rTotal+0.0)) * 100);
		r11=(int) (((r11+0.0)/(rTotal+0.0)) * 100);
		r12=(int) (((r12+0.0)/(rTotal+0.0)) * 100);
		r13=(int) (((r13+0.0)/(rTotal+0.0)) * 100);
		r14=(int) (((r14+0.0)/(rTotal+0.0)) * 100);
		r15=(int) (((r15+0.0)/(rTotal+0.0)) * 100);
		r16=(int) (((r16+0.0)/(rTotal+0.0)) * 100);
		r17=(int) (((r17+0.0)/(rTotal+0.0)) * 100);
		
		int [] equipF = new int []{
		r1,
		r2,
		r3,
		r4,
		r5,
		r6,
		r7,
		r8,
		r9,
		r10,
		r11,
		r12,
		r13,
		r14,
		r15,
		r16,
		r17
		};
		
		String [] tempEquip = new String [] {
				"Projector"
				,"Video Cassette Recorder"
				,"Television"
				,"White Board"
				,"Tape Recorder"
				,"Slide Projector"
				,"PA System"
				,"Microphone Stand"
				,"Microphone"
				,"Sound Amplifier"
				,"Speaker"
				,"Heater"
				,"Fan"
				,"HDMI Cable"
				,"Extenstion Cable"
				,"Network Cable"
				,"AirCon"
		};
		for(int i = 0; i < tempEquip.length; i++){
			series_equipmentFrequencyBarChart.getData().add(new XYChart.Data<String, Number>(tempEquip[i], equipF[i]));
			roomEquipmentTable.getItems().add(new EquipmentStats(tempEquip[i], equipF[i]));
		}
	}
	@SuppressWarnings("unchecked")
	public void createWaitingListTable(){
		waitingListTable = new TableView<>();
		TableColumn<BookingDTO, String> employeeNameColumn = new TableColumn<>("Employee");
		employeeNameColumn.setMinWidth(200);
		employeeNameColumn.setCellValueFactory(new PropertyValueFactory<>("clientName"));

		TableColumn<BookingDTO, String> roomNameColumn = new TableColumn<>("Room Name");
		roomNameColumn.setMinWidth(200);
		roomNameColumn.setCellValueFactory(new PropertyValueFactory<>("roomName"));
		
		TableColumn<BookingDTO, String> timeColumn = new TableColumn<>("Date And Time");
		timeColumn.setMinWidth(200);
		timeColumn.setCellValueFactory(new PropertyValueFactory<>("dateStart"));
		
		waitingListTable.getColumns().addAll(employeeNameColumn, roomNameColumn, timeColumn);
		waitingListTable.setOnMouseClicked(e -> {
			BookingDTO current = waitingListTable.getSelectionModel().getSelectedItem();
			if(current!=null){
				try {
					ShowEquipment.displayWith(current);
				} catch (ClassNotFoundException | IOException e1) {
					e1.printStackTrace();
				}
			}
		});
	}
	public void setWaitlistData(Date from, Date to) throws ClassNotFoundException, IOException, ParseException{
		waitingListTable.getItems().clear();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		for(BookingDTO wait : ClientFX.getInstance().getBookingsForStats()){
			if(wait.isBooked().equalsIgnoreCase("Waiting")){
				System.out.println(wait);
				if(formatter.parse(wait.getStartDate()).after(from)&&formatter.parse(wait.getEndDate()).before(to)){
					waitingListTable.getItems().add(wait);
				}
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

package za.co.vzap.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;



@SuppressWarnings("serial")
public class MainFrame extends JFrame{
	private static JFrame frame;
	private static JPanel bluePanel;
	private static JMenuBar menuBar = null ;
	private static JMenu fileMenu , homeMenu , viewMenu , searchMenu , helpMenu = null ;
	
	private static JMenuItem fileMI , homeMI , viewMI , searchMI , helpMI = null ;
	
	public MainFrame() {
		super("Reservation System");
		setBackground(Color.BLACK);
		frame = new JFrame();
		frame.setTitle("Reservation System");
		createGUI();
	}
	
	
	
	private static void createGUI() {
		menuBar = new JMenuBar();
		fileMenu = new JMenu("File");
		homeMenu = new JMenu("Home");
		viewMenu = new JMenu("View");
		searchMenu = new JMenu("Search");
		helpMenu = new JMenu("Help");
		
		fileMI = new JMenuItem("Go to login page");
		fileMI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L , ActionEvent.CTRL_MASK));
		fileMI.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						
	
						addToFrame(LoginPanel.login.getInstance());
						
						
					}
			
				});
		homeMI = new JMenuItem("Go to home page");
		homeMI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H , ActionEvent.CTRL_MASK));
		homeMI.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						
						addToFrame(MainMenu.main.getInstance());
						
						
					}
			
				});
		viewMI = new JMenuItem("View Reports");
		viewMI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V , ActionEvent.CTRL_MASK));
		viewMI.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						
						addToFrame(ReportPage.rp.returnReportPage());
						
						
						
					}
			
				});
		searchMI = new JMenuItem("Go to search page");
		searchMI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S , ActionEvent.CTRL_MASK));
		searchMI.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent e) {
						
						addToFrame(Questionnaire.ques.returnQues());
						
						
						
					}
			
				});
		helpMI = new JMenuItem("Go to help page");
		
		fileMenu.add(fileMI);
		homeMenu.add(homeMI);
		viewMenu.add(viewMI);
		searchMenu.add(searchMI);
		helpMenu.add(helpMI);
		menuBar.add(fileMenu);
		menuBar.add(homeMenu);
		menuBar.add(viewMenu);
		menuBar.add(searchMenu);
		menuBar.add(helpMenu);
		
		bluePanel = new JPanel(new GridLayout(1, 1));
		bluePanel.setBackground(Color.BLUE);
		bluePanel.add(LoginPanel.login.getInstance());
		
		frame.add(bluePanel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize(new Dimension(800,700));
		frame.setMaximumSize(new Dimension(800,700));
		frame.setLocation(300, -1);
		frame.pack();
		frame.setJMenuBar(menuBar);
		frame.setResizable(false);
		frame.setVisible(true);
		
	}
	
	public static void addToFrame(JPanel comp){
		System.out.println("adding...");
		bluePanel.removeAll();
		bluePanel.validate();
		bluePanel.repaint();
		bluePanel.add(comp);
		bluePanel.validate();
		bluePanel.repaint();
		
	}



	public static void main(String [] args){
		new MainFrame();
	}
}

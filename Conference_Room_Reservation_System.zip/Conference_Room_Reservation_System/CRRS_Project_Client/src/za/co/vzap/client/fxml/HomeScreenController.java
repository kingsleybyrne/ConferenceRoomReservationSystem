package za.co.vzap.client.fxml;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import com.jfoenix.controls.JFXButton;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import za.co.vzap.client.fx.ClientFX;
import za.co.vzap.dto.BookingDTO;

public class HomeScreenController implements Initializable{
	@FXML
	private MenuItem menuHome;
	@FXML
	private MenuItem menuClose;
	@FXML
	private MenuItem menuQuestionnaire;
	@FXML
	private MenuItem menuSearch;
	@FXML
	private MenuItem menuReports;
	@FXML
	private MenuItem menuHelp;
	@FXML
	private Label clock;
	@FXML
	private AnchorPane ap;
	@FXML
	private JFXButton newMeetingBTN;
	@FXML
	private JFXButton helpBTN;
	@FXML
	private JFXButton loginBTN;
	@FXML
	private JFXButton searchBTN;
	@FXML
	private JFXButton reportsBTN;
	@FXML
	private Label roomNameLbl;
	@FXML
	private Label dateLbl;
	@FXML
	private Label timeLbl;
	@FXML
	private Label descrpLbl;
	@FXML
	private JFXButton cancelBtn;
	@FXML
	private ListView<String> pendingsList;
	private BookingDTO nextBooking;
	private static Scene questionnaireScreen;
	private static Scene searchScreen;
	private static Scene reportsScreen;
	@FXML
	private TableView<BookingDTO> pendingsTable;
	@FXML
	private TableView<BookingDTO> scheduledTable;
	
	public HomeScreenController(){
		
	}
	
	private void displayNextMeeting() {
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat timeFormat = new SimpleDateFormat("HH:mm");
		try {
			Date current = formatter.parse(formatter.format(new Date()));
			Date time = timeFormat.parse(timeFormat.format(current.getTime()));
			
			if( ClientFX.getInstance().returnBookings().size() == 0){				
				dateLbl.setText("Currerntly no meeting scheduled for today !");
				roomNameLbl.setText("");
				timeLbl.setText("");
				descrpLbl.setText("");
				cancelBtn.setDisable(true);
				
			}
			for(BookingDTO b : ClientFX.getInstance().returnBookings()){
				if(b.isBooked().equalsIgnoreCase("booked")){
					if(formatter.parse(b.getStartDate().substring(0, 10)).equals(current)){
						//i changed something here
						if(timeFormat.parse(b.getStartDate().substring(11)).after(time) && b!=nextBooking){
							roomNameLbl.setText(b.getRoomName());
							dateLbl.setText(formatter.format(current));
							timeLbl.setText(timeFormat.format(timeFormat.parse(b.getStartDate().substring(11)))+ "-" +timeFormat.format(timeFormat.parse(b.getEndDate().substring(11))));
							descrpLbl.setText(b.getMeetingDescription());
							nextBooking = b;
							cancelBtn.setDisable(false);
						} else {
							dateLbl.setText("Currerntly no meeting scheduled for today !");
							roomNameLbl.setText("-");
							timeLbl.setText("-");
							descrpLbl.setText("-");
							cancelBtn.setDisable(true);
						}
					} else {
						dateLbl.setText("Currerntly no meeting scheduled for today !");
						roomNameLbl.setText("-");
						timeLbl.setText("-");
						descrpLbl.setText("-");
						cancelBtn.setDisable(true);
					}
				} else {
					dateLbl.setText("Currerntly no meeting scheduled for today !");
					roomNameLbl.setText("-");
					timeLbl.setText("-");
					descrpLbl.setText("-");
					cancelBtn.setDisable(true);
				}
				
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
	}
	public void refresh(){	
		displayNextMeeting();
		setTables();
	}

	private void setTables() {
		pendingsTable.getItems().clear();
		scheduledTable.getItems().clear();
		ArrayList<BookingDTO> list = ClientFX.getInstance().returnBookings();
		if(list.isEmpty())
		{
			scheduledTable.getItems().add(new BookingDTO("-", "-", "-", "-", "-", "Currently there is no scheduled meetings", "-", 0));
			pendingsTable.getItems().add(new BookingDTO("-", "-", "-", "-", "-", "Currently there is no pending meetings", "-", 0));
		}
		for(BookingDTO b : list){
			if(b.isBooked().equalsIgnoreCase("pending")){
				pendingsTable.getItems().add(b);
			} else {
				if(!(b.isBooked().equalsIgnoreCase("Cancelled"))){
					scheduledTable.getItems().add(b);
				}			
			}
		}
		if(pendingsTable.getItems().isEmpty()){
			System.out.println("True empty");
			
			pendingsTable.getItems().add(new BookingDTO("-", "-", "-", "-", "-", "Currently there is no pending meetings", "-", 0));
		}
		if(scheduledTable.getItems().isEmpty()){			
			scheduledTable.getItems().add(new BookingDTO("-", "-", "-", "-", "-", "Currently there is no scheduled meetings", "-", 0));
		}
		
	}

	public void gotoQuestionnairePanel() throws IOException{
		Parent pquestionnaireScreen = FXMLLoader.load(getClass().getResource("QuestionnaireScreen.fxml"));
		questionnaireScreen = new Scene(pquestionnaireScreen); 
		MainStage.getStage().setScene(questionnaireScreen);
	}
	public static Scene getQuestionnaireScreen(){
		return questionnaireScreen;
	}
	
	public void gotoSearchPanel() throws IOException{
		System.out.println("Flag goto search");
		Parent psearchScreen = FXMLLoader.load(getClass().getResource("SearchScreen.fxml"));
		System.out.println("Flag psearchScreen");
		searchScreen = new Scene(psearchScreen);
		System.out.println("Flag searchScreen");
		MainStage.getStage().setScene(searchScreen);
		System.out.println("Flag MainStage");
	}
	public static Scene getSearchScreen() {
		return searchScreen;
	}
	public void gotoReportsPanel() throws IOException{
		
		Parent preportsScreen = FXMLLoader.load(getClass().getResource("Reports.fxml"));
		reportsScreen = new Scene(preportsScreen);
		MainStage.getStage().setScene(reportsScreen);
	}
	public static Scene getReportsScreen() {
		return reportsScreen;
	}
	
	private void clock(){
		DateFormat timeFormat = new SimpleDateFormat( "HH:mm" );
		KeyFrame key = new KeyFrame(
		        Duration.millis( 250 ),
		        event -> {
		        	Calendar cal = Calendar.getInstance();
		            clock.setText(timeFormat.format(cal.getTime()));
		        }
		    );
		final Timeline timeline = new Timeline(key);
		timeline.setCycleCount( Animation.INDEFINITE );
		timeline.play();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		clock();
		new ArrayList<>();
		displayNextMeeting();
		
		createPendingTable();
		createScheduledTable();
		setTables();
	}
	
	@SuppressWarnings("unchecked")
	private void createPendingTable() {
		TableColumn<BookingDTO, String> nameColumn = new TableColumn<>("Room Name");
		nameColumn.setMinWidth(280);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("roomName"));

		TableColumn<BookingDTO, String> dateColumn = new TableColumn<>("Date and Time");
		dateColumn.setMinWidth(170);
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));

		TableColumn<BookingDTO, String> descriptionColumn = new TableColumn<>("Meeting Description");
		descriptionColumn.setMinWidth(200);
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("meetingDescription"));
		
		TableColumn<BookingDTO, String> noOfAttColumn = new TableColumn<>("No. Of Attendees");
		noOfAttColumn.setMinWidth(150);
		noOfAttColumn.setCellValueFactory(new PropertyValueFactory<>("noOfAttendees"));
		
		pendingsTable.getColumns().addAll(nameColumn, dateColumn, descriptionColumn, noOfAttColumn);
	}
	@SuppressWarnings("unchecked")
	private void createScheduledTable() {
		TableColumn<BookingDTO, String> nameColumn = new TableColumn<>("Room Name");
		nameColumn.setMinWidth(200);
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("roomName"));

		TableColumn<BookingDTO, String> dateColumn = new TableColumn<>("Date and Time");
		dateColumn.setMinWidth(200);
		dateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));

		TableColumn<BookingDTO, String> descriptionColumn = new TableColumn<>("Meeting Description");
		descriptionColumn.setMinWidth(200);
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("meetingDescription"));
		
		TableColumn<BookingDTO, String> statusColumn = new TableColumn<>("Status");
		statusColumn.setMinWidth(200);
		statusColumn.setCellValueFactory(new PropertyValueFactory<>("booked"));
		
		scheduledTable.getColumns().addAll(nameColumn, dateColumn, descriptionColumn, statusColumn);
	}
	
	
	public void handlePendingTable(){
		ObservableList<BookingDTO> selected, allPendingBookings;
		allPendingBookings = pendingsTable.getItems();
		selected = pendingsTable.getSelectionModel().getSelectedItems();
		if(pendingsTable.getSelectionModel().getSelectedItem()!=null && pendingsTable.getSelectionModel().getSelectedItem().getNoOfAttendees()!=0){
			int a = AlertBox.display("Confirmation", "Confirm Booking?", "Yes", "No");
			if(a == 0){	

				String value = pendingsTable.getSelectionModel().getSelectedItem().getRoomName();
				String date = pendingsTable.getSelectionModel().getSelectedItem().getStartDate();
				ClientFX.getInstance().confirmBooking(ClientFX.getInstance().getClient().getClientName(), ClientFX.getInstance().getClient().getClientSurname(),
						value, date);

				selected.forEach(allPendingBookings::remove);
			} else {
				if(a == 1){

					String value = pendingsTable.getSelectionModel().getSelectedItem().getRoomName();
					String date = pendingsTable.getSelectionModel().getSelectedItem().getStartDate();
					ClientFX.getInstance().cancelBooking(ClientFX.getInstance().getClient().getClientName(), ClientFX.getInstance().getClient().getClientSurname(),
							value, date);

					ClientFX.getInstance().updateWaitingList(value, date);
					selected.forEach(allPendingBookings::remove);
				}
			}
		}
	}
	
	public void handleScheduledTable(){
		ObservableList<BookingDTO> selected, otherBookings;
		otherBookings = scheduledTable.getItems();
		selected = scheduledTable.getSelectionModel().getSelectedItems();
		System.out.println(selected);
		if(scheduledTable.getSelectionModel().getSelectedItem()!=null && scheduledTable.getSelectionModel().getSelectedItem().getNoOfAttendees()!=0){
			int a = AlertBox.display("Cancellation", "Cancel Booking?", "Yes", "No");
			if(a == 0){	
				
				String value = scheduledTable.getSelectionModel().getSelectedItem().getRoomName();
				String date = scheduledTable.getSelectionModel().getSelectedItem().getStartDate();
				ClientFX.getInstance().cancelBooking(ClientFX.getInstance().getClient().getClientName(), ClientFX.getInstance().getClient().getClientSurname(),
						value, date);
				
				selected.forEach(otherBookings::remove);
				ClientFX.getInstance().updateWaitingList(value, date);
			}
		}
	}
	public void cancelNextMeeting(){
		if(nextBooking!=null){
			ClientFX.getInstance().cancelBooking(ClientFX.getInstance().getClient().getClientName(), ClientFX.getInstance().getClient().getClientSurname(), nextBooking.getRoomName(),nextBooking.getStartDate());
			ClientFX.getInstance().updateWaitingList(nextBooking.getRoomName(), nextBooking.getStartDate());
			displayNextMeeting();
		}
		displayNextMeeting();
	}
	
	
	public void gotoHomeScreen(){
		MainStage.getStage().setScene(LoginScreenController.getHomeScreen());
	}
	public void closeTheProgram(){
		MainStage.getStage().close();
		System.exit(0);
	}
	public void gotoQuestionnaireScreen() throws IOException{
		if(questionnaireScreen == null){
			gotoQuestionnairePanel();
		} else {
			MainStage.getStage().setScene(questionnaireScreen);
		}
	}
	public void gotoSearchScreen() throws IOException{
		if(searchScreen == null){
			gotoSearchPanel();
		} else {
			MainStage.getStage().setScene(searchScreen);
		}
	}
	public void gotoReports() throws IOException{
		if(reportsScreen == null){
			gotoReportsPanel();
		} else {
			MainStage.getStage().setScene(reportsScreen);
		}
	}
	public void gotoHelpPage(){
		
	}
	public void gotoLogin(){
		MainStage.getStage().setScene(MainStage.getLoginScreen());
	}	
}

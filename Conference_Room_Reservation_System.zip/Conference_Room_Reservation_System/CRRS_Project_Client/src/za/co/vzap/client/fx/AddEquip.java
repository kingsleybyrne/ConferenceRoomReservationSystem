package za.co.vzap.client.fx;

public class AddEquip {
		public String enterE;
		public String enterQ;
		public AddEquip(String equipment, String quantity){
			enterE = equipment;
			enterQ = quantity;
		}
		public String getS(){
			return enterE;
		}
		public String getT(){
			return enterQ;
		}
}

package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.border.BevelBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import za.co.vzap.graph.StatsBarGraphRoomUse;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class RoomReport extends JPanel {
	private JPanel viewRoomChartBtn;
	private JPanel nPanel;
	private JLabel lblRoomReport;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton btnViewVisualRepresentation;
	public static RoomReport rr = new RoomReport();
	private JButton return2ReportBtn;

	/**
	 * Create the panel.
	 */
	public RoomReport() {
		
		viewRoomChartBtn = new JPanel();
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(viewRoomChartBtn, GroupLayout.PREFERRED_SIZE, 602, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(viewRoomChartBtn, GroupLayout.PREFERRED_SIZE, 396, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		nPanel = new JPanel();
		nPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		
		scrollPane = new JScrollPane();
		
		btnViewVisualRepresentation = new JButton("View Room Chart");
		btnViewVisualRepresentation.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnViewVisualRepresentation.addActionListener(e->{
			try {
				Controller.getInstance().displayRoomChart();
			} catch (ClassNotFoundException | SQLException | IOException e1) {
				
				e1.printStackTrace();
			}
		});
		
		return2ReportBtn = new JButton("> Return to Report Page");
		return2ReportBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Controller.getInstance().displayReportPage();
			}
		});
		GroupLayout gl_viewRoomChartBtn = new GroupLayout(viewRoomChartBtn);
		gl_viewRoomChartBtn.setHorizontalGroup(
			gl_viewRoomChartBtn.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_viewRoomChartBtn.createSequentialGroup()
					.addGroup(gl_viewRoomChartBtn.createParallelGroup(Alignment.LEADING)
						.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 216, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_viewRoomChartBtn.createSequentialGroup()
							.addGap(79)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 435, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_viewRoomChartBtn.createSequentialGroup()
							.addGap(248)
							.addComponent(btnViewVisualRepresentation)))
					.addContainerGap(88, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_viewRoomChartBtn.createSequentialGroup()
					.addContainerGap(484, Short.MAX_VALUE)
					.addComponent(return2ReportBtn)
					.addGap(29))
		);
		gl_viewRoomChartBtn.setVerticalGroup(
			gl_viewRoomChartBtn.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_viewRoomChartBtn.createSequentialGroup()
					.addComponent(nPanel, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnViewVisualRepresentation)
					.addPreferredGap(ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
					.addComponent(return2ReportBtn)
					.addContainerGap())
		);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Amazon", null, null},
				{"Congo", null, null},
				{"Ebro", null, null},
				{"Ganges", null, null},
				{"Mississippi", null, null},
				{"Mosman", null, null},
				{"Nile", null, null},
				{"Ottawa", null, null},
				{"Rhine", null, null},
				{"Seine", null, null},
				{"Thames", null, null},
				{"Zambezi", null, null},
			},
			new String[] {
				"Room", "Times Used", "%"
			}
		));
		
		lblRoomReport = new JLabel("Room Report");
		lblRoomReport.setFont(new Font("Tahoma", Font.BOLD, 15));
		GroupLayout gl_nPanel = new GroupLayout(nPanel);
		gl_nPanel.setHorizontalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_nPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblRoomReport)
					.addContainerGap(109, Short.MAX_VALUE))
		);
		gl_nPanel.setVerticalGroup(
			gl_nPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_nPanel.createSequentialGroup()
					.addGap(24)
					.addComponent(lblRoomReport)
					.addContainerGap(25, Short.MAX_VALUE))
		);
		nPanel.setLayout(gl_nPanel);
		viewRoomChartBtn.setLayout(gl_viewRoomChartBtn);
		setLayout(groupLayout);

	}
	public JPanel returnRoomReport() {
		return rr;
	}
}

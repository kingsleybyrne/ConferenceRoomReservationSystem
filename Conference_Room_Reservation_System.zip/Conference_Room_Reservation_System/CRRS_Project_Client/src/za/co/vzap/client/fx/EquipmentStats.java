package za.co.vzap.client.fx;

public class EquipmentStats {
	private String equipmentName;
	private int frequency;
	
	public EquipmentStats(String equipmentName, int frequency) {
		this.equipmentName = equipmentName;
		this.frequency = frequency;
	}
	
	
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
}

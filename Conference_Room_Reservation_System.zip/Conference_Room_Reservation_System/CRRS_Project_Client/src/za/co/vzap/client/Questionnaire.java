package za.co.vzap.client;

import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.SystemColor;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Questionnaire extends JPanel implements ActionListener {
	private JPanel questionnairePanel;
	private JPanel nPanel;
	private JLabel lblMeetingDetails;
	private JPanel userPanel;
	private JLabel nameLbl;
	private JLabel surnameLbl;
	private JLabel cellNoLbl;
	private JLabel deptLbl;
	private JLabel userLogoLbl;
	private JPanel startTimePanel;
	private JDateChooser fromDateChooser;
	private JLabel fromLbl;
	private JLabel toLbl;
	private JDateChooser dateChooser;
	private JLabel timeLbl;
	private JComboBox startTimeBox;
	private JLabel userLbl;
	private JPanel noOfAttendeesPanel;
	private JComboBox noOfAttendeesBox;
	private JLabel lblSelectNumberOf;
	private JButton searchBtn;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblSessions;
	private JComboBox sessionsBox;
	public static Questionnaire ques = new Questionnaire();
	private JButton btnSelectRoom;
	private int count = 0;
	

	/**
	 * Create the panel.
	 */
	public Questionnaire() {
		setLayout(null);
		
		questionnairePanel = new JPanel();
		questionnairePanel.setBounds(0, 0, 753, 580);
		add(questionnairePanel);
		questionnairePanel.setLayout(null);
		
		nPanel = new JPanel();
		nPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		nPanel.setBounds(0, 0, 218, 64);
		questionnairePanel.add(nPanel);
		nPanel.setLayout(null);
		
		lblMeetingDetails = new JLabel("Meeting Details");
		lblMeetingDetails.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblMeetingDetails.setBounds(10, 23, 128, 19);
		nPanel.add(lblMeetingDetails);
		
		userPanel = new JPanel();
		userPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		userPanel.setBounds(465, 0, 265, 108);
		questionnairePanel.add(userPanel);
		userPanel.setLayout(null);
		
		nameLbl = new JLabel("Name : ");
		nameLbl.setBounds(91, 8, 171, 14);
		userPanel.add(nameLbl);
		
		surnameLbl = new JLabel("Surname : ");
		surnameLbl.setBounds(91, 33, 171, 14);
		userPanel.add(surnameLbl);
		
		cellNoLbl = new JLabel("Cellphone Number : ");
		cellNoLbl.setBounds(91, 58, 181, 14);
		userPanel.add(cellNoLbl);
		
		deptLbl = new JLabel("Department : ");
		deptLbl.setBounds(91, 83, 171, 14);
		userPanel.add(deptLbl);
		
		userLbl = new JLabel("");
		userLbl.setIcon(new ImageIcon("C:\\Users\\Graham\\Downloads\\icons8-administrator-male-50.png"));
		userLbl.setBounds(10, 22, 57, 50);
		userPanel.add(userLbl);
		
		userLogoLbl = new JLabel("userLogo");
		userLogoLbl.setBounds(24, 33, 51, 59);
		//panel.add(userLogoLbl);
		userLogoLbl.setIcon(new ImageIcon("C:\\Users\\Graham\\Downloads\\icons8-administrator-male-50.png"));
		startTimePanel = new JPanel();
		startTimePanel.setBackground(Color.LIGHT_GRAY);
		startTimePanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Date Range", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))));
		startTimePanel.setBounds(10, 127, 405, 161);
		questionnairePanel.add(startTimePanel);
		startTimePanel.setLayout(null);
		
		fromDateChooser = new JDateChooser();
		fromDateChooser.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date from = fromDateChooser.getDate();
				fromLbl.setText("From : " + from);
				
				
			}
		});
		fromDateChooser.setBounds(10, 58, 115, 20);
		startTimePanel.add(fromDateChooser);
		
		fromLbl = new JLabel("From : ");
		fromLbl.setBounds(10, 33, 115, 14);
		startTimePanel.add(fromLbl);
		
		toLbl = new JLabel("To :");
		toLbl.setBounds(134, 33, 115, 14);
		startTimePanel.add(toLbl);
		
		dateChooser = new JDateChooser();
		dateChooser.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String to = dateChooser.getDateFormatString();
				toLbl.setText("To : " + to);
				
			}
		});
		dateChooser.setBounds(134, 58, 115, 20);
		startTimePanel.add(dateChooser);
		
		timeLbl = new JLabel("Starting at :");
		timeLbl.setBounds(10, 89, 91, 14);
		startTimePanel.add(timeLbl);
		
		startTimeBox = new JComboBox();
		startTimeBox.setModel(new DefaultComboBoxModel(new String[] {"08:00 AM", "08:30 AM", "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 AM", "12:30 PM", "13:00 PM\t", "13:30 PM", "14:00 PM", "14:30 PM", "15:00 PM", "15:30 PM", "16:00 PM", "16:30 PM"}));
		startTimeBox.setBounds(10, 114, 81, 20);
		startTimePanel.add(startTimeBox);
		
		lblSessions = new JLabel("Sessions :");
		lblSessions.setBounds(134, 89, 91, 14);
		startTimePanel.add(lblSessions);
		
		sessionsBox = new JComboBox();
		sessionsBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		sessionsBox.setBounds(134, 114, 46, 20);
		startTimePanel.add(sessionsBox);
		
		noOfAttendeesPanel = new JPanel();
		noOfAttendeesPanel.setLayout(null);
		noOfAttendeesPanel.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null), new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Number of Attendees", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0))));
		noOfAttendeesPanel.setBackground(Color.LIGHT_GRAY);
		noOfAttendeesPanel.setBounds(10, 299, 405, 70);
		questionnairePanel.add(noOfAttendeesPanel);
		
		noOfAttendeesBox = new JComboBox();
		noOfAttendeesBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		noOfAttendeesBox.setBounds(227, 26, 51, 20);
		noOfAttendeesPanel.add(noOfAttendeesBox);
		
		lblSelectNumberOf = new JLabel("Select number of attendees :");
		lblSelectNumberOf.setBounds(23, 29, 180, 14);
		noOfAttendeesPanel.add(lblSelectNumberOf);
		
		searchBtn = new JButton("Search");
		searchBtn.addActionListener(e -> {
			Controller.getInstance().searchRoomsAvail();
		});
		searchBtn.setBounds(435, 324, 89, 23);
		questionnairePanel.add(searchBtn);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 392, 405, 158);
		questionnairePanel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Room", "Capacity", "Date Available", "Time Available"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(102);
		table.getColumnModel().getColumn(2).setPreferredWidth(135);
		
		btnSelectRoom = new JButton("Select Room");
		btnSelectRoom.addActionListener(this);
		btnSelectRoom.setBounds(425, 456, 126, 23);
		questionnairePanel.add(btnSelectRoom);
		
	}	
	public JPanel returnQues()
	{
		Controller.getInstance().setUserDetails();
		return ques ;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == btnSelectRoom)
		{
			Controller.getInstance().displayScheduleMeeting();
		}
		
	}
	public String getRoom() {
		
		return (String) table.getModel().getValueAt(table.getSelectedRow(), 0);
	}
	public int getNoOfAtt() {
		return Integer.parseInt((String) noOfAttendeesBox.getSelectedItem());
	}
	public void addRoomsToTable(String roomName, String capacity, String date){
		table.getModel().setValueAt(roomName, count, 0);
		table.getModel().setValueAt(capacity, count, 1);
		table.getModel().setValueAt(date, count, 2);
		count++;
	}
	public Date getFromDate(){
		return fromDateChooser.getDate();
	}
	public void setUserDetails(String name, String surname, String cellNo, String department){
		nameLbl.setText(nameLbl.getText() + name);
		surnameLbl.setText(surnameLbl.getText() + surname);
		cellNoLbl.setText(cellNoLbl.getText() + cellNo);
		deptLbl.setText(deptLbl.getText() + department);
	}
	public Date getToDate(){
		return dateChooser.getDate();
	}
	public String getStartTime() {
		return (String) startTimeBox.getSelectedItem();
	}
	public String getEndTime(){
		String endTime = (String) startTimeBox.getSelectedItem();
		return endTime;
		
	}
}

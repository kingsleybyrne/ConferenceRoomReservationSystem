package za.co.vzap.dto;

import java.io.Serializable;

public class EquipmentDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String equipmentName;
	
	public EquipmentDTO(String equipmentName){
		setEquipmentName(equipmentName);
	}

	public String getEquipmentName() {
		return equipmentName;
	}

	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}

	@Override
	public String toString() {
		return "EquipmentDTO [equipmentName=" + equipmentName + "]";
	}
	
}

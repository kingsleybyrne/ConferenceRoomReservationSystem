package za.co.vzap.face;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openimaj.image.ImageUtilities;

import com.twelvemonkeys.image.BufferedImageFactory;

public class captureFace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FaceDetector faceDetector = null;
		try {
			faceDetector = new FaceDetector();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedImageFactory image=new BufferedImageFactory(ImageUtilities.createBufferedImage(faceDetector.detectFace()));
		BufferedImage bImage=image.getBufferedImage();
		File file=new File("resources/faceKingsley5.jpg");
		try {
			//bImage=ImageIO.read(file);
			ImageIO.write(bImage, "jpg", file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

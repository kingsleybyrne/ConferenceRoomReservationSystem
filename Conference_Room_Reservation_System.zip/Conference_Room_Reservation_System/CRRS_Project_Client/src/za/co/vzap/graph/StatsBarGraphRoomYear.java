package za.co.vzap.graph;

import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import za.co.vzap.dto.RoomReportDTO;

public class StatsBarGraphRoomYear extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatsBarGraphRoomYear(CategoryDataset createDataset) throws SQLException, IOException {
		String chartTitle="Weekly Room Statistics";
	      JFreeChart barChart = ChartFactory.createBarChart(
	         chartTitle,           
	         "Room",            
	         "% Full",            
	         createDataset,          
	         PlotOrientation.VERTICAL,           
	         true, true, false);
	         
	      ChartPanel chartPanel = new ChartPanel( barChart );        
	      setLayout(new GridLayout(1, 1));      
			File pieChart = new File( "resources/StatsYearlyUseBarChart.jpeg" ); 
		    int width = 640;   /* Width of the image */
		    int height = 480; 
		    ChartUtilities.saveChartAsJPEG( pieChart , barChart , width , height );
		    add(chartPanel);
			this.setVisible( true ); 
	}
	 public static CategoryDataset createDataset(ArrayList<RoomReportDTO> list ) throws SQLException {
	      
		  ArrayList<RoomReportDTO> roomList=list;
		  
		  final DefaultCategoryDataset dataset = 
			      new DefaultCategoryDataset( );  
		  
		  for(int i=0;i<roomList.size();i++){
			  dataset.addValue(roomList.get(i).getPercentageFull(),roomList.get(i).getRoomName(), "% Full");
		  }             

	      return dataset; 
	   }

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		try {
//			new StatsBarGraphRoomYear();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

}

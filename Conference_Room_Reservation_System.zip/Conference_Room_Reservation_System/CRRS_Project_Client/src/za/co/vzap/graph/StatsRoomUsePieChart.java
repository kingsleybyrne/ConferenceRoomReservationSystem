package za.co.vzap.graph;

import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import za.co.vzap.dto.RoomDTO;

public class StatsRoomUsePieChart extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static ArrayList<RoomDTO> roomList = new ArrayList<RoomDTO>();

	public StatsRoomUsePieChart() throws SQLException, IOException{
		setLayout(new GridLayout(1, 1));
		add(createPanel());
		setVisible(true);
	}
	
	public static void setList(ArrayList<RoomDTO> list){
		roomList = new ArrayList<RoomDTO>();
		roomList.addAll(list);
	}
	public PieDataset createDataset() throws SQLException {
		DefaultPieDataset dataset = new DefaultPieDataset( );
		
		 double nCount = 0, sCount = 0, eCount = 0, wCount = 0;
		 
		for(int i = 0; i < roomList.size(); i++){
			if(roomList.get(i).getBuildingName().equalsIgnoreCase("North")){
				nCount += roomList.get(i).getRoomCount();
			}
			if(roomList.get(i).getBuildingName().equalsIgnoreCase("South")){
				sCount += roomList.get(i).getRoomCount();
			}
			if(roomList.get(i).getBuildingName().equalsIgnoreCase("East")){
				eCount += roomList.get(i).getRoomCount();
			}
			if(roomList.get(i).getBuildingName().equalsIgnoreCase("West")){
				wCount += roomList.get(i).getRoomCount();
			}
		}
		
		dataset.setValue("North", new Double( nCount ));
		dataset.setValue("South", new Double( sCount ));
		dataset.setValue("East", new Double( eCount ));
		dataset.setValue("West", new Double( wCount ));
		
		return dataset;
	}

	private JFreeChart createChart() throws IOException, SQLException {
		JFreeChart chart = ChartFactory.createPieChart(      
				"Building Use",   // chart title 
				createDataset(),          // data    
				true,             // include legend   
				true, 
				false);
		File pieChart = new File( "resources/StatsRoomUsePieChart.jpeg" ); 
		int width = 640;   /* Width of the image */
		int height = 480; 
		ChartUtilities.saveChartAsJPEG( pieChart , chart , width , height );
		return chart;
	}

	private JPanel createPanel() throws SQLException {
		JFreeChart chart = null;
		try {
			chart = createChart();
		} catch (IOException e) {
			e.printStackTrace();
		}  
		return new ChartPanel( chart ); 
	}
	
}

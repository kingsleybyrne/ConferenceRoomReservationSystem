package za.co.vzap.graph;

import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import za.co.vzap.dto.RoomCancellationsDTO;

public class StatsBarGraphRoomCancellations extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatsBarGraphRoomCancellations(CategoryDataset dataset) throws SQLException, IOException{
		String chartTitle="Room Cancellation Statistics";
		JFreeChart barChart = ChartFactory.createBarChart(
				chartTitle,           
				"Room Cancellations",            
				"Cancellations",            
				dataset,          
				PlotOrientation.VERTICAL,           
				true, true, false);
		ChartPanel chartPanel = new ChartPanel( barChart );        
//		chartPanel.setPreferredSize(new java.awt.Dimension( 1200 , 800 ) );        
		File pieChart = new File( "resources/StatsRoomCancellationsBarChart.jpeg" ); 
		int width = 640;   /* Width of the image */
		int height = 480; 
		ChartUtilities.saveChartAsJPEG( pieChart , barChart , width , height );
		
		this.setLayout(new GridLayout(1, 1));
		add(chartPanel);
		this.setVisible( true ); 
	}
	public static CategoryDataset createDataset(ArrayList<RoomCancellationsDTO> list ) throws SQLException {

		ArrayList<RoomCancellationsDTO> roomCancelList=list;

		final DefaultCategoryDataset dataset = 
				new DefaultCategoryDataset( );  

		for(int i=0;i<roomCancelList.size();i++){
			dataset.addValue(roomCancelList.get(i).getRoomCancellations(), roomCancelList.get(i).getRoomName(), "Cancelled");
		}             
		return dataset; 
	}

}

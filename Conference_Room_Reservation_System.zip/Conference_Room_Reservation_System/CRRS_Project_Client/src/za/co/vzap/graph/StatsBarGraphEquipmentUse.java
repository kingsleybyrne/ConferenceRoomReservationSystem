package za.co.vzap.graph;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;


import za.co.vzap.dto.RoomEquipmentDTO;

public class StatsBarGraphEquipmentUse extends JPanel {
	private static final long serialVersionUID = 1L;
	private static final String fileName = "resources/StatsEquipmentUseBarChart.jpeg";
	public StatsBarGraphEquipmentUse(CategoryDataset dataset) throws SQLException, IOException {
		String chartTitle="Equipment Use Statistics";
		JFreeChart barChart = ChartFactory.createBarChart(
				chartTitle,           
				"Equipment",            
				"Uses",            
				dataset,          
				PlotOrientation.VERTICAL,           
				true, true, false);

		ChartPanel chartPanel = new ChartPanel( barChart );        
//		chartPanel.setPreferredSize(new java.awt.Dimension( 1200 , 800 ) );        
		File pieChart = new File( fileName ); 
		int width = 640;   /* Width of the image */
		int height = 480; 
		ChartUtilities.saveChartAsJPEG( pieChart , barChart , width , height );
		add(chartPanel);
		this.setVisible( true ); 
	}
	public static CategoryDataset createDataset(ArrayList<RoomEquipmentDTO> list ) throws SQLException {

		//	      MySqlReportDAO listDAO =new MySqlReportDAO();
		ArrayList<RoomEquipmentDTO> equipmentList=(ArrayList<RoomEquipmentDTO>)list;

		final DefaultCategoryDataset dataset = 
				new DefaultCategoryDataset( );  

		for(int i=0;i<equipmentList.size();i++){
			dataset.addValue(equipmentList.get(i).getEquipmentQuantity(),equipmentList.get(i).getRoomEquipment(), "Usage");
		}             

		return dataset; 
	}
	public static String getFileName(){
		return fileName;
	}

}

package za.co.vzap.graph;

import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

import za.co.vzap.dto.RoomReportDTO;

public class StatsRoomMonthlyUsePieChart extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatsRoomMonthlyUsePieChart(String date, ArrayList<RoomReportDTO> roomList) throws SQLException {
		 setLayout(new GridLayout(1, 1));
		 add(createDemoPanel(date, roomList));
		this.setVisible( true ); 
	}
	private PieDataset createDataset(String date, ArrayList<RoomReportDTO> list) throws SQLException { //Add String date
		DefaultPieDataset dataset = new DefaultPieDataset( );
		ArrayList<RoomReportDTO> roomList = list;
		
		for(int i=0;i<roomList.size();i++){
				dataset.setValue(roomList.get(i).getRoomName(), new Double(roomList.get(i).getPercentageFull()));
		}

		return dataset;         
	}

	private JFreeChart createChart( PieDataset dataset ) throws IOException {
		JFreeChart chart = ChartFactory.createPieChart(      
				"Room Monthly % Use",   // chart title 
				dataset,          // data    
				true,             // include legend   
				true, 
				false);
		File pieChart = new File( "resources/StatsRoomMonthlyUsePieChart.jpeg" ); 
		int width = 640;   /* Width of the image */
		int height = 480; 
		ChartUtilities.saveChartAsJPEG( pieChart , chart , width , height );
		return chart;
	}

	public JPanel createDemoPanel(String date, ArrayList<RoomReportDTO> list) throws SQLException {
		JFreeChart chart = null;
		try {
			chart = createChart( createDataset(date, list) );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return new ChartPanel( chart ); 
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		try {
//			new StatsRoomMonthlyUsePieChart();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

}

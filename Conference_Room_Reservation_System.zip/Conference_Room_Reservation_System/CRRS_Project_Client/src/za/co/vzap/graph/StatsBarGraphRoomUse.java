package za.co.vzap.graph;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;


import za.co.vzap.dto.RoomDTO;

public class StatsBarGraphRoomUse extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StatsBarGraphRoomUse(CategoryDataset dataset) throws SQLException, IOException {
		String chartTitle="Room Use Statistics";
	      JFreeChart barChart = ChartFactory.createBarChart(
	         chartTitle,           
	         "Room",            
	         "Uses",            
	         dataset,          
	         PlotOrientation.VERTICAL,           
	         true, true, false);
	         
	      ChartPanel chartPanel = new ChartPanel( barChart );        
//	      chartPanel.setPreferredSize(new java.awt.Dimension( 1200 , 800 ) );        
	      
			File pieChart = new File( "resources/StatsRoomUseBarChart.jpeg" ); 
		    int width = 640;   /* Width of the image */
		    int height = 480; 
		    ChartUtilities.saveChartAsJPEG( pieChart , barChart , width , height );
		    add(chartPanel);
			this.setVisible( true ); 
	}
	 public static CategoryDataset createDataset(ArrayList<RoomDTO> list ) throws SQLException {
	      
		  ArrayList<RoomDTO> roomList=list;
		  
		  final DefaultCategoryDataset dataset = 
			      new DefaultCategoryDataset( );  
		  
		  for(int i=0;i<roomList.size();i++){
			  dataset.addValue(roomList.get(i).getRoomCount(), roomList.get(i).getRoomName(), "Occupied");
		  }             

	      return dataset; 
	 }

}
